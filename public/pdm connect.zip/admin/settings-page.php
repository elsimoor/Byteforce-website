<?php
// Admin Settings Page

function nextjs_sync_add_admin_menu() {
    add_options_page(
        'NextJS Sync Settings',
        'NextJS Sync',
        'manage_options',
        'nextjs-sync',
        'nextjs_sync_options_page'
    );
}

function nextjs_sync_settings_init() {
    register_setting('nextjs_sync_plugin_options', 'nextjs_sync_settings');

    add_settings_section(
        'nextjs_sync_api_section', 
        'API Settings', 
        'nextjs_sync_api_section_callback', 
        'nextjs_sync_plugin_options'
    );

    add_settings_field(
        'api_url', 
        'NextJS API URL', 
        'nextjs_sync_api_url_render', 
        'nextjs_sync_plugin_options', 
        'nextjs_sync_api_section'
    );

    add_settings_field(
        'api_secret', 
        'API Secret Key', 
        'nextjs_sync_api_secret_render', 
        'nextjs_sync_plugin_options', 
        'nextjs_sync_api_section'
    );
}
add_action('admin_init', 'nextjs_sync_settings_init');

function nextjs_sync_api_url_render() {
    $options = get_option('nextjs_sync_settings');
    $api_url = isset($options['api_url']) ? $options['api_url'] : '';
    ?>
    <input type='url' name='nextjs_sync_settings[api_url]' value='<?php echo esc_attr($api_url); ?>' class="regular-text">
    <p class="description">Example: https://api.yoursite.com/page-sync</p>
    <?php
}

function nextjs_sync_api_secret_render() {
    $options = get_option('nextjs_sync_settings');
    $api_secret = isset($options['api_secret']) ? $options['api_secret'] : '';
    ?>
    <input type='password' name='nextjs_sync_settings[api_secret]' value='<?php echo esc_attr($api_secret); ?>' class="regular-text">
    <?php
}

function nextjs_sync_api_section_callback() {
    echo '<p>Configure the webhook URL and authentication secret to sync pages with Next.js.</p>';
}

function nextjs_sync_options_page() {
    ?>
    <div class="wrap">
        <h2>NextJS Sync Settings</h2>
        <form action='options.php' method='post'>
            <?php
            settings_fields('nextjs_sync_plugin_options');
            do_settings_sections('nextjs_sync_plugin_options');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
