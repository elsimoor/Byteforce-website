<?php
/**
 * Plugin Name: NextJS Page Sync
 * Description: Export Gutenberg block structure and sync it to a Next.js Node API via webhook on page save.
 * Version: 1.0.0
 * Author: Walid Moultamiss
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define Plugin Path
define('NEXTJS_SYNC_PATH', plugin_dir_path(__FILE__));

// Include admin settings
require_once NEXTJS_SYNC_PATH . 'admin/settings-page.php';

// Include webhook export logic
require_once NEXTJS_SYNC_PATH . 'includes/exporter.php';
require_once NEXTJS_SYNC_PATH . 'includes/sync.php';

// Include iframe embed and auto-login logic
require_once NEXTJS_SYNC_PATH . 'includes/iframe-allow.php';
require_once NEXTJS_SYNC_PATH . 'includes/auto-login.php';

// Initialize the plugin settings and hooks
add_action('admin_menu', 'nextjs_sync_add_admin_menu');
add_action('save_post', 'nextjs_sync_handle_save_post', 10, 3);
