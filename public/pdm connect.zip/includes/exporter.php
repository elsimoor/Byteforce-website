<?php
// Extract blocks and send to Node API

function nextjs_sync_export_page_to_api($post_id, $post) {
    if ($post->post_status !== 'publish') {
        // We only want to sync published pages for now
        // Feel free to remove this to sync drafts
        // return; 
    }

    $options = get_option('nextjs_sync_settings');
    $api_url = isset($options['api_url']) ? $options['api_url'] : '';
    $api_secret = isset($options['api_secret']) ? $options['api_secret'] : '';

    if (empty($api_url)) {
        return; // Nothing to sync to
    }

    // Parse blocks
    $blocks = parse_blocks($post->post_content);
    
    // Clean up blocks to strip out empty HTML wrapper blocks correctly
    $clean_blocks = [];
    foreach ($blocks as $block) {
        if (!empty($block['blockName'])) {
            $clean_blocks[] = [
                'blockName' => $block['blockName'],
                'attrs' => isset($block['attrs']) ? $block['attrs'] : [],
                'innerHTML' => trim($block['innerHTML'])
            ];
        } else if (!empty(trim($block['innerHTML']))) {
            // Unnamed raw HTML blocks (classic editor leftovers or standard html)
            $clean_blocks[] = [
                'blockName' => 'core/html',
                'attrs' => [],
                'innerHTML' => trim($block['innerHTML'])
            ];
        }
    }

    $payload = [
        'pageId' => $post_id,
        'slug' => $post->post_name,
        'title' => get_the_title($post_id),
        'blocks' => $clean_blocks,
        'html' => apply_filters('the_content', $post->post_content), // Full raw html fallback
        'updatedAt' => current_time('mysql', 1)
    ];

    $args = [
        'body'        => wp_json_encode($payload),
        'timeout'     => 15,
        'blocking'    => false, // Async execution (don't stall WordPress save ui)
        'headers'     => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_secret
        ],
    ];

    // Fire webhook natively in WP
    wp_remote_post($api_url, $args);
}
