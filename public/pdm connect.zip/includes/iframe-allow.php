<?php
/**
 * Handle Iframe Security and Environment
 */

// 1. Remove X-Frame-Options to allow embedding
function nextjs_sync_allow_iframe_embed() {
    remove_action('admin_init', 'send_frame_options_header');
    remove_action('login_init', 'send_frame_options_header');
}
add_action('init', 'nextjs_sync_allow_iframe_embed');

// 2. Add SameSite=None and Secure to all WP cookies using PHP 7.3+ array options if available, 
// and intercepting the headers otherwise.
function nextjs_sync_cookie_samesite( $cookie_string ) {
	// Already processed?
	if ( stripos( $cookie_string, 'SameSite=None' ) !== false ) {
		return $cookie_string;
	}

	// Remove old SameSite or Secure
	$cookie_string = preg_replace( '/;\s*SameSite=[a-zA-Z]+/i', '', $cookie_string );
	$cookie_string = preg_replace( '/;\s*Secure/i', '', $cookie_string );

	// Force None and Secure
	$cookie_string .= '; SameSite=None; Secure';

	return $cookie_string;
}

// Hook into PHP's header construction to rewrite Set-Cookie before browser payload
function nextjs_sync_catch_cookies() {
	if ( headers_sent() ) {
		return;
	}

	$headers = headers_list();
	$cookie_headers = [];

	foreach ( $headers as $header ) {
		if ( stripos( $header, 'Set-Cookie:' ) === 0 ) {
			$cookie_headers[] = substr( $header, 11 ); // remove "Set-Cookie:"
		}
	}

	if ( empty( $cookie_headers ) ) {
		return;
	}

	// Remove original cookie headers
	header_remove( 'Set-Cookie' );

	// Write rewritten cookies
	foreach ( $cookie_headers as $cookie ) {
		header( 'Set-Cookie: ' . nextjs_sync_cookie_samesite( trim( $cookie ) ), false );
	}
}

// Fire at initialization and login 
add_action( 'init', 'nextjs_sync_catch_cookies', 9999 );
add_action( 'login_init', 'nextjs_sync_catch_cookies', 9999 );
add_action( 'admin_init', 'nextjs_sync_catch_cookies', 9999 );
add_action( 'send_headers', 'nextjs_sync_catch_cookies', 9999 );

// Hook into WordPress directly setting the auth cookie params (WP 5.2+)
add_action('set_auth_cookie', 'nextjs_sync_set_auth_cookie', 10, 5);
add_action('set_logged_in_cookie', 'nextjs_sync_set_auth_cookie', 10, 5);

function nextjs_sync_set_auth_cookie($auth_cookie, $expire, $expiration, $user_id, $scheme) {
    if (PHP_VERSION_ID >= 70300) {
        // We can't strictly overwrite WP's setcookie params after it was called, 
        // but we ensure the catch_cookies interceptor above triggers.
        nextjs_sync_catch_cookies();
    }
}
