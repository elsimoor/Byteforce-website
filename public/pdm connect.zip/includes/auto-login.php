<?php
/**
 * Ultimate Frontend Gutenberg Bypass - NO LOGIN REQUIRED
 */

// 1. Instantly assign Administrator role BEFORE WordPress checks authentication
// This hooks into the very first user determination filter in WP natively.
add_filter('determine_current_user', function($user_id) {
    // If the browser already has a valid WP cookie, use it (e.g. you're actually logged in)
    if (!empty($user_id)) {
        return $user_id; 
    }

    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    
    // If we are on the public /new-page-editor OR it's a background API save from that editor
    if (strpos($request_uri, '/new-page-editor') !== false || isset($_GET['public_editor_save'])) {
        // Find the first Administrator account and forcefully assume their identity in memory
        $admins = get_users(['role' => 'administrator']);
        if (!empty($admins)) {
            return $admins[0]->ID;
        }
    }
    
    return $user_id;
}, 9999); // Highest priority so plugins don't overwrite it


// 2. Kill the auth_redirect loop dead in its tracks
// WordPress's `auth_redirect()` function forcefully sends unauthenticated users 
// to wp-login.php. We hook into it right before it fires and CANCEL the redirect.
add_action('auth_redirect', function() {
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($request_uri, '/new-page-editor') !== false || isset($_GET['public_editor_save'])) {
        // By echoing nothing and exiting, we literally cancel the wp-login.php redirect!
        return true; 
    }
}, 1); // Run instantly


// 3. Disable X-Frame-Options to allow embedding in the Next.js Iframe
add_action('admin_init', function() {
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($request_uri, '/new-page-editor') !== false) {
        remove_action('admin_init', 'send_frame_options_header');
    }
}, 1);

// 4. Intercept the /new-page-editor URL and load the Gutenberg Editor inline
add_action('parse_request', function() {
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    
    if (strpos($request_uri, '/new-page-editor') !== false) {
        
        // Trick core WP into thinking we're safely in the admin dashboard natively
        if (!defined('WP_ADMIN')) define('WP_ADMIN', true);
        $_SERVER['PHP_SELF'] = '/wp-admin/post-new.php';
        $_GET['post_type'] = 'page';
        $_REQUEST['post_type'] = 'page';
        
        global $pagenow;
        $pagenow = 'post-new.php';

        // Completely hide the black WP Admin sidebar, top bar, and footer via CSS.
        // This makes it look like a 100% custom frontend editor page.
        add_action('admin_head', function() {
            echo '<style>
                #adminmenumain, #wpadminbar, #wpfooter, .update-nag, .notice { display: none !important; visibility: hidden !important; }
                #wpcontent, #wpbody-content { margin-left: 0 !important; padding: 0 !important; }
                html.wp-toolbar { padding-top: 0 !important; }
                body { background: #fff !important; }
                .edit-post-layout__header { top: 0 !important; }
                .interface-interface-skeleton__header { top: 0 !important; }
                .edit-post-sidebar { top: 0 !important; }
                .edit-post-header { border-top: 0 !important; }
            </style>';
        });
        
        // Inject a flag into background Gutenberg "Publish" requests
        // so our determine_current_user hook (Step 1) knows to authenticate the save.
        add_action('enqueue_block_editor_assets', function() {
            wp_add_inline_script('wp-api-fetch', "
                wp.apiFetch.use(function(options, next) {
                    if (typeof options.url === 'string') {
                        options.url += (options.url.indexOf('?') === -1 ? '?' : '&') + 'public_editor_save=true';
                    } else if (typeof options.path === 'string') {
                        options.path += (options.path.indexOf('?') === -1 ? '?' : '&') + 'public_editor_save=true';
                    }
                    return next(options);
                });
            ");
        }, 999);
        
        // Finally, load the core WordPress Admin Bootstrap and Editor Screen inline
        require_once ABSPATH . 'wp-admin/admin.php';
        require_once ABSPATH . 'wp-admin/post-new.php';
        exit;
    }
}, 1);
