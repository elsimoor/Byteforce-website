<?php
// Hook save post and dispatch to exporter

function nextjs_sync_handle_save_post($post_id, $post, $update) {
    // Only sync if it's a genuine post/page save avoiding autosaves, revisions etc.
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
        return;
    }

    // Check post type (typically page or post)
    $allowed_post_types = ['page', 'post'];
    if (!in_array($post->post_type, $allowed_post_types)) {
        return;
    }

    // Trigger export
    nextjs_sync_export_page_to_api($post_id, $post);
}
