<?php
/**
 * Local installed plugins view.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'get_plugins' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$pd_plugins = get_plugins();
$pd_search  = isset( $_GET['pd_s'] ) ? sanitize_text_field( wp_unslash( $_GET['pd_s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$pd_error   = isset( $_GET['pd_export'] ) ? sanitize_text_field( wp_unslash( $_GET['pd_export'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

if ( '' !== $pd_search ) {
	$needle = strtolower( $pd_search );
	$pd_plugins = array_filter(
		$pd_plugins,
		function ( $data, $file ) use ( $needle ) {
			$haystack = strtolower(
				$data['Name'] . ' ' . $data['Description'] . ' ' . $file . ' ' . ( isset( $data['Author'] ) ? $data['Author'] : '' )
			);
			return false !== strpos( $haystack, $needle );
		},
		ARRAY_FILTER_USE_BOTH
	);
}
?>
<div class="wrap plugin-downloader-wrap plugin-downloader-local-wrap">
	<h1><?php esc_html_e( 'Local Plugins', 'plugin-downloader' ); ?></h1>
	<p class="plugin-downloader-lead"><?php esc_html_e( 'Download a ZIP of any plugin already installed on this site.', 'plugin-downloader' ); ?></p>

	<?php if ( '' !== $pd_error ) : ?>
		<div class="notice notice-error">
			<p><?php echo esc_html( $pd_error ); ?></p>
		</div>
	<?php endif; ?>

	<form method="get" class="plugin-downloader-search-form plugin-downloader-local-filter">
		<input type="hidden" name="page" value="<?php echo esc_attr( Plugin_Downloader_Admin::PAGE_LOCAL ); ?>" />
		<label class="screen-reader-text" for="plugin-downloader-local-search"><?php esc_html_e( 'Search installed plugins', 'plugin-downloader' ); ?></label>
		<input
			type="search"
			id="plugin-downloader-local-search"
			class="plugin-downloader-search-input"
			name="pd_s"
			value="<?php echo esc_attr( $pd_search ); ?>"
			placeholder="<?php echo esc_attr__( 'Filter installed plugins…', 'plugin-downloader' ); ?>"
		/>
		<button type="submit" class="button"><?php esc_html_e( 'Filter', 'plugin-downloader' ); ?></button>
	</form>

	<table class="widefat striped plugin-downloader-local-table">
		<thead>
			<tr>
				<th scope="col"><?php esc_html_e( 'Plugin', 'plugin-downloader' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Version', 'plugin-downloader' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Status', 'plugin-downloader' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Actions', 'plugin-downloader' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $pd_plugins ) ) : ?>
				<tr>
					<td colspan="4"><?php esc_html_e( 'No installed plugins matched your filter.', 'plugin-downloader' ); ?></td>
				</tr>
			<?php else : ?>
				<?php foreach ( $pd_plugins as $pd_file => $pd_data ) : ?>
					<?php
					$pd_active = is_plugin_active( $pd_file ) || ( is_multisite() && is_plugin_active_for_network( $pd_file ) );
					$pd_url    = Plugin_Downloader_Local_Export::get_download_url( $pd_file );
					$pd_author = isset( $pd_data['Author'] ) ? wp_strip_all_tags( $pd_data['Author'] ) : '';
					?>
					<tr>
						<td>
							<strong><?php echo esc_html( $pd_data['Name'] ); ?></strong>
							<?php if ( '' !== $pd_author ) : ?>
								<div class="plugin-downloader-card-author"><?php echo esc_html( sprintf( /* translators: %s: plugin author */ __( 'By %s', 'plugin-downloader' ), $pd_author ) ); ?></div>
							<?php endif; ?>
							<div class="plugin-downloader-local-file"><code><?php echo esc_html( $pd_file ); ?></code></div>
						</td>
						<td><?php echo esc_html( isset( $pd_data['Version'] ) ? $pd_data['Version'] : '' ); ?></td>
						<td>
							<?php
							if ( $pd_active ) {
								esc_html_e( 'Active', 'plugin-downloader' );
							} else {
								esc_html_e( 'Inactive', 'plugin-downloader' );
							}
							?>
						</td>
						<td>
							<?php if ( '' !== $pd_url ) : ?>
								<a class="button button-primary" href="<?php echo esc_url( $pd_url ); ?>">
									<?php esc_html_e( 'Download ZIP', 'plugin-downloader' ); ?>
								</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>
</div>
