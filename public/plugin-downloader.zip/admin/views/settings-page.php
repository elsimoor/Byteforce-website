<?php
/**
 * Settings admin view.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap plugin-downloader-wrap plugin-downloader-settings-wrap">
	<h1><?php esc_html_e( 'Plugin Downloader Settings', 'plugin-downloader' ); ?></h1>

	<?php settings_errors(); ?>

	<?php if ( is_multisite() ) : ?>
		<div class="notice notice-info">
			<p><?php esc_html_e( 'On Multisite, these settings are stored per site. Open this screen from a site dashboard to configure that site.', 'plugin-downloader' ); ?></p>
		</div>
	<?php endif; ?>

	<form action="<?php echo esc_url( admin_url( 'options.php' ) ); ?>" method="post">
		<?php
		settings_fields( Plugin_Downloader_Settings::GROUP );
		do_settings_sections( 'plugin-downloader-settings' );
		submit_button( __( 'Save Changes', 'plugin-downloader' ) );
		?>
	</form>
</div>
