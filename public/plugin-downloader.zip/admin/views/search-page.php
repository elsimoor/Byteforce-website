<?php
/**
 * Search plugins admin view.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap plugin-downloader-wrap" id="plugin-downloader-app">
	<h1 class="wp-heading-inline"><?php esc_html_e( 'Plugin Downloader', 'plugin-downloader' ); ?></h1>
	<p class="plugin-downloader-lead"><?php esc_html_e( 'Search and install plugins from WordPress.org', 'plugin-downloader' ); ?></p>

	<?php if ( is_multisite() && is_network_admin() ) : ?>
		<div class="notice notice-info">
			<p><?php esc_html_e( 'You are in Network Admin. Plugins can be downloaded and installed here, but they will not be network-activated. Activate them from each site’s Plugins screen.', 'plugin-downloader' ); ?></p>
		</div>
	<?php elseif ( is_multisite() ) : ?>
		<div class="notice notice-info">
			<p><?php esc_html_e( 'This is a Multisite installation. Installed plugins are available to the whole network. Activation applies only to this site.', 'plugin-downloader' ); ?></p>
		</div>
	<?php endif; ?>

	<?php if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) : ?>
		<div class="notice notice-warning">
			<p><?php esc_html_e( 'Plugin installation is disabled on this site (DISALLOW_FILE_MODS). You can still search and download ZIPs from WordPress.org.', 'plugin-downloader' ); ?></p>
		</div>
	<?php endif; ?>

	<noscript>
		<div class="notice notice-error">
			<p><?php esc_html_e( 'Plugin Downloader requires JavaScript in wp-admin to search and install plugins.', 'plugin-downloader' ); ?></p>
		</div>
	</noscript>

	<div class="plugin-downloader-notices" id="plugin-downloader-notices" aria-live="polite"></div>

	<div class="plugin-downloader-search-panel">
		<h2><?php esc_html_e( 'Search WordPress Plugins', 'plugin-downloader' ); ?></h2>
		<form class="plugin-downloader-search-form" id="plugin-downloader-search-form" action="#" method="get">
			<label class="screen-reader-text" for="plugin-downloader-search-input"><?php esc_html_e( 'Search plugins', 'plugin-downloader' ); ?></label>
			<input
				type="search"
				id="plugin-downloader-search-input"
				class="plugin-downloader-search-input"
				name="s"
				value=""
				placeholder="<?php echo esc_attr__( 'Search plugins…', 'plugin-downloader' ); ?>"
				autocomplete="off"
			/>
			<button type="submit" class="button button-primary" id="plugin-downloader-search-submit">
				<?php esc_html_e( 'Search', 'plugin-downloader' ); ?>
			</button>
			<span class="spinner" id="plugin-downloader-search-spinner" hidden></span>
		</form>
	</div>

	<div
		id="plugin-downloader-status"
		class="plugin-downloader-status"
		role="status"
		aria-live="polite"
	><?php esc_html_e( 'Enter a keyword to search the WordPress.org plugin directory.', 'plugin-downloader' ); ?></div>

	<div id="plugin-downloader-results" class="plugin-downloader-results"></div>

	<nav
		id="plugin-downloader-pagination"
		class="plugin-downloader-pagination"
		aria-label="<?php echo esc_attr__( 'Search results pages', 'plugin-downloader' ); ?>"
		hidden
	></nav>
</div>
