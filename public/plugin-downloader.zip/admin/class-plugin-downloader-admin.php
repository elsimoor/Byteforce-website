<?php
/**
 * Admin menus, screens, and assets.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WordPress admin UI for Plugin Downloader.
 */
class Plugin_Downloader_Admin {

	/**
	 * Search page slug.
	 *
	 * @var string
	 */
	const PAGE_SEARCH = 'plugin-downloader';

	/**
	 * Settings page slug.
	 *
	 * @var string
	 */
	const PAGE_SETTINGS = 'plugin-downloader-settings';

	/**
	 * Local plugins page slug.
	 *
	 * @var string
	 */
	const PAGE_LOCAL = 'plugin-downloader-local';

	/**
	 * Script and style handle.
	 *
	 * @var string
	 */
	const SCRIPT_HANDLE = 'plugin_downloader_admin';

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'network_admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_filter( 'plugin_action_links_' . PD_PLUGIN_BASENAME, array( $this, 'plugin_action_links' ) );
		add_filter( 'network_admin_plugin_action_links_' . PD_PLUGIN_BASENAME, array( $this, 'plugin_action_links' ) );
	}

	/**
	 * Top-level menu and submenus.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_menu_page(
			__( 'Plugin Downloader', 'plugin-downloader' ),
			__( 'Plugin Downloader', 'plugin-downloader' ),
			'install_plugins',
			self::PAGE_SEARCH,
			array( $this, 'render_search_page' ),
			'dashicons-download',
			65
		);

		add_submenu_page(
			self::PAGE_SEARCH,
			__( 'Search Plugins', 'plugin-downloader' ),
			__( 'Search Plugins', 'plugin-downloader' ),
			'install_plugins',
			self::PAGE_SEARCH,
			array( $this, 'render_search_page' )
		);

		add_submenu_page(
			self::PAGE_SEARCH,
			__( 'Local Plugins', 'plugin-downloader' ),
			__( 'Local Plugins', 'plugin-downloader' ),
			'install_plugins',
			self::PAGE_LOCAL,
			array( $this, 'render_local_page' )
		);

		add_submenu_page(
			self::PAGE_SEARCH,
			__( 'Settings', 'plugin-downloader' ),
			__( 'Settings', 'plugin-downloader' ),
			'install_plugins',
			self::PAGE_SETTINGS,
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Enqueue CSS/JS only on this plugin's screens.
	 *
	 * @param string $hook Current admin hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		$allowed_hooks = array(
			'toplevel_page_' . self::PAGE_SEARCH,
			'plugin-downloader_page_' . self::PAGE_SETTINGS,
			'plugin-downloader_page_' . self::PAGE_LOCAL,
			'toplevel_page_' . self::PAGE_SEARCH . '-network',
			'plugin-downloader_page_' . self::PAGE_SETTINGS . '-network',
			'plugin-downloader_page_' . self::PAGE_LOCAL . '-network',
		);

		if ( ! in_array( $hook, $allowed_hooks, true ) ) {
			return;
		}

		$handle = self::SCRIPT_HANDLE;
		$base   = PD_PLUGIN_URL . 'admin/assets/';

		wp_enqueue_style( $handle, $base . 'css/admin.css', array(), PD_VERSION );

		$is_search = ( 'toplevel_page_' . self::PAGE_SEARCH === $hook || 'toplevel_page_' . self::PAGE_SEARCH . '-network' === $hook );
		if ( ! $is_search ) {
			return;
		}

		wp_enqueue_script( $handle, $base . 'js/admin.js', array(), PD_VERSION, true );
		wp_localize_script( $handle, 'pluginDownloader', $this->get_script_data() );
	}

	/**
	 * Data passed to the admin script.
	 *
	 * @return array
	 */
	private function get_script_data() {
		return array(
			'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
			'nonce'          => wp_create_nonce( 'plugin_downloader_admin' ),
			'perPage'        => Plugin_Downloader_Settings::get_per_page(),
			'autoActivate'   => Plugin_Downloader_Settings::get_auto_activate(),
			'isMultisite'    => is_multisite(),
			'isNetworkAdmin' => is_network_admin(),
			'canActivate'    => Plugin_Downloader_Security::current_user_can_activate(),
			'strings'        => $this->js_strings(),
		);
	}

	/**
	 * Translated strings for JavaScript.
	 *
	 * @return array
	 */
	private function js_strings() {
		return array(
			'searching'            => __( 'Searching WordPress.org...', 'plugin-downloader' ),
			'search'               => __( 'Search', 'plugin-downloader' ),
			'noResults'            => __( 'No plugins found. Try a different search term.', 'plugin-downloader' ),
			'emptySearch'          => __( 'Please enter a search term.', 'plugin-downloader' ),
			'resultsCount'         => __( '%1$s results', 'plugin-downloader' ),
			'pageStatus'           => __( 'Page %1$s of %2$s', 'plugin-downloader' ),
			'previous'             => __( 'Previous', 'plugin-downloader' ),
			'next'                 => __( 'Next', 'plugin-downloader' ),
			'download'             => __( 'Download', 'plugin-downloader' ),
			'install'              => __( 'Install', 'plugin-downloader' ),
			'installActivate'      => __( 'Install & Activate', 'plugin-downloader' ),
			'activate'             => __( 'Activate', 'plugin-downloader' ),
			'active'               => __( 'Active', 'plugin-downloader' ),
			'alreadyInstalled'     => __( 'Already Installed', 'plugin-downloader' ),
			'installing'           => __( 'Installing...', 'plugin-downloader' ),
			'activating'           => __( 'Activating...', 'plugin-downloader' ),
			'downloading'          => __( 'Preparing download...', 'plugin-downloader' ),
			'installed'            => __( 'Plugin installed.', 'plugin-downloader' ),
			'installedActivated'   => __( 'Plugin installed and activated.', 'plugin-downloader' ),
			'activated'            => __( 'Plugin activated.', 'plugin-downloader' ),
			'requestFailed'        => __( 'The request failed. Please try again.', 'plugin-downloader' ),
			'requestInterrupted'   => __( 'The request was interrupted. Please try again.', 'plugin-downloader' ),
			'byAuthor'             => __( 'By %s', 'plugin-downloader' ),
			'version'              => __( 'Version %s', 'plugin-downloader' ),
			'installs'             => __( '%s installs', 'plugin-downloader' ),
			'rating'               => __( '%1$s out of 5 stars (%2$s ratings)', 'plugin-downloader' ),
			'updated'              => __( 'Updated %s', 'plugin-downloader' ),
			'requiresWp'           => __( 'Requires WordPress %s', 'plugin-downloader' ),
			'testedWp'             => __( 'Tested up to %s', 'plugin-downloader' ),
			'requiresPhp'          => __( 'Requires PHP %s', 'plugin-downloader' ),
			'incompatibleWp'       => __( 'This plugin requires a newer version of WordPress.', 'plugin-downloader' ),
			'incompatiblePhp'      => __( 'This plugin requires a newer version of PHP.', 'plugin-downloader' ),
			'networkNoActivate'    => __( 'Activation is not available in Network Admin. Install the plugin here, then activate it from each site.', 'plugin-downloader' ),
			'noPermissionInstall'  => __( 'You do not have permission to install plugins.', 'plugin-downloader' ),
			'pluginIconAlt'        => __( 'Plugin icon', 'plugin-downloader' ),
			'dismissNotice'        => __( 'Dismiss this notice.', 'plugin-downloader' ),
		);
	}

	/**
	 * Search screen.
	 *
	 * @return void
	 */
	public function render_search_page() {
		if ( ! Plugin_Downloader_Security::current_user_can_install() ) {
			wp_die(
				esc_html__( 'You do not have permission to install plugins.', 'plugin-downloader' ),
				esc_html__( 'Forbidden', 'plugin-downloader' ),
				array( 'response' => 403 )
			);
		}

		include PD_PLUGIN_DIR . 'admin/views/search-page.php';
	}

	/**
	 * Local installed plugins screen.
	 *
	 * @return void
	 */
	public function render_local_page() {
		if ( ! Plugin_Downloader_Security::current_user_can_install() ) {
			wp_die(
				esc_html__( 'You do not have permission to download plugins.', 'plugin-downloader' ),
				esc_html__( 'Forbidden', 'plugin-downloader' ),
				array( 'response' => 403 )
			);
		}

		include PD_PLUGIN_DIR . 'admin/views/local-plugins-page.php';
	}

	/**
	 * Settings screen.
	 *
	 * @return void
	 */
	public function render_settings_page() {
		if ( ! Plugin_Downloader_Security::current_user_can_manage_settings() ) {
			wp_die(
				esc_html__( 'You do not have permission to manage these settings.', 'plugin-downloader' ),
				esc_html__( 'Forbidden', 'plugin-downloader' ),
				array( 'response' => 403 )
			);
		}

		include PD_PLUGIN_DIR . 'admin/views/settings-page.php';
	}

	/**
	 * Plugins list table links.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		if ( ! Plugin_Downloader_Security::current_user_can_install() ) {
			return $links;
		}

		$url = is_network_admin()
			? network_admin_url( 'admin.php?page=' . self::PAGE_SEARCH )
			: admin_url( 'admin.php?page=' . self::PAGE_SEARCH );

		$search_link = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Search Plugins', 'plugin-downloader' ) . '</a>';
		array_unshift( $links, $search_link );

		return $links;
	}
}
