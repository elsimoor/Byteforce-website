/**
 * Plugin Downloader admin UI.
 */
(function () {
	'use strict';

	var config = window.pluginDownloader || {};
	var strings = config.strings || {};
	var form = document.getElementById('plugin-downloader-search-form');

	if (!form) {
		return;
	}

	var input = document.getElementById('plugin-downloader-search-input');
	var submit = document.getElementById('plugin-downloader-search-submit');
	var spinner = document.getElementById('plugin-downloader-search-spinner');
	var statusEl = document.getElementById('plugin-downloader-status');
	var resultsEl = document.getElementById('plugin-downloader-results');
	var paginationEl = document.getElementById('plugin-downloader-pagination');
	var noticesEl = document.getElementById('plugin-downloader-notices');

	var searchController = null;
	var currentPage = 1;
	var currentSearch = '';
	var busySlugs = {};

	form.addEventListener('submit', function (event) {
		event.preventDefault();
		runSearch(1);
	});

	function runSearch(page) {
		var term = (input.value || '').trim();
		if (!term) {
			setStatus(strings.emptySearch || 'Please enter a search term.', true);
			resultsEl.innerHTML = '';
			hidePagination();
			return;
		}

		currentSearch = term;
		currentPage = page || 1;

		if (searchController && typeof searchController.abort === 'function') {
			searchController.abort();
		}

		searchController = typeof AbortController === 'function' ? new AbortController() : null;

		setSearching(true);
		setStatus(strings.searching || 'Searching WordPress.org…', false);

		var body = new FormData();
		body.append('action', 'plugin_downloader_search');
		body.append('nonce', config.nonce || '');
		body.append('search', term);
		body.append('page', String(currentPage));

		var fetchOpts = {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		};
		if (searchController) {
			fetchOpts.signal = searchController.signal;
		}

		fetch(config.ajaxUrl, fetchOpts)
			.then(parseJson)
			.then(function (payload) {
				setSearching(false);
				if (!payload || !payload.success) {
					setStatus(errorMessage(payload), true);
					resultsEl.innerHTML = '';
					hidePagination();
					return;
				}
				renderResults(payload.data || {});
			})
			.catch(function (error) {
				if (error && error.name === 'AbortError') {
					return;
				}
				setSearching(false);
				setStatus(strings.requestFailed || 'The request failed. Please try again.', true);
			});
	}

	function renderResults(data) {
		var plugins = data.plugins || [];
		var info = data.info || {};
		var results = typeof info.results === 'number' ? info.results : plugins.length;
		var pages = typeof info.pages === 'number' ? info.pages : 1;
		var page = typeof info.page === 'number' ? info.page : currentPage;

		resultsEl.innerHTML = '';

		if (!plugins.length) {
			setStatus(strings.noResults || 'No plugins found. Try a different search term.', false);
			hidePagination();
			return;
		}

		setStatus(sprintf(strings.resultsCount || '%1$s results', formatNumber(results)), false);

		plugins.forEach(function (plugin) {
			resultsEl.appendChild(renderCard(plugin));
		});

		renderPagination(page, pages);
	}

	function renderCard(plugin) {
		var card = document.createElement('article');
		card.className = 'plugin-downloader-card';
		card.setAttribute('data-slug', plugin.slug || '');

		card.appendChild(renderIcon(plugin));

		var body = document.createElement('div');
		body.className = 'plugin-downloader-card-body';

		var title = document.createElement('h3');
		title.className = 'plugin-downloader-card-title';
		title.textContent = plugin.name || plugin.slug || '';
		body.appendChild(title);

		if (plugin.short_description) {
			var desc = document.createElement('p');
			desc.className = 'plugin-downloader-card-desc';
			desc.textContent = plugin.short_description;
			body.appendChild(desc);
		}

		if (plugin.author) {
			var author = document.createElement('p');
			author.className = 'plugin-downloader-card-author';
			author.textContent = sprintf(strings.byAuthor || 'By %s', plugin.author);
			body.appendChild(author);
		}

		body.appendChild(renderMeta(plugin));
		body.appendChild(renderCompat(plugin));

		if (!plugin.compatible_wp) {
			body.appendChild(warning(strings.incompatibleWp || 'This plugin requires a newer version of WordPress.'));
		} else if (!plugin.compatible_php) {
			body.appendChild(warning(strings.incompatiblePhp || 'This plugin requires a newer version of PHP.'));
		}

		body.appendChild(renderActions(plugin));
		card.appendChild(body);
		return card;
	}

	function renderIcon(plugin) {
		var wrap = document.createElement('div');
		wrap.className = 'plugin-downloader-card-icon';

		if (plugin.icon && isSafeIconUrl(plugin.icon)) {
			var img = document.createElement('img');
			img.src = plugin.icon;
			img.alt = strings.pluginIconAlt || 'Plugin icon';
			img.width = 64;
			img.height = 64;
			wrap.appendChild(img);
		} else {
			var icon = document.createElement('span');
			icon.className = 'dashicons dashicons-admin-plugins';
			icon.setAttribute('aria-hidden', 'true');
			wrap.appendChild(icon);
		}

		return wrap;
	}

	function renderMeta(plugin) {
		var list = document.createElement('ul');
		list.className = 'plugin-downloader-card-meta';

		if (plugin.version) {
			list.appendChild(metaItem(sprintf(strings.version || 'Version %s', plugin.version)));
		}

		if (plugin.active_installs_text) {
			list.appendChild(metaItem(sprintf(strings.installs || '%s installs', plugin.active_installs_text)));
		}

		if (plugin.last_updated) {
			list.appendChild(metaItem(sprintf(strings.updated || 'Updated %s', plugin.last_updated)));
		}

		var ratingItem = document.createElement('li');
		ratingItem.className = 'plugin-downloader-rating';
		var stars = document.createElement('span');
		stars.className = 'plugin-downloader-stars';
		stars.setAttribute('aria-hidden', 'true');
		var fill = document.createElement('span');
		fill.className = 'plugin-downloader-stars-fill';
		fill.style.width = Math.max(0, Math.min(100, Number(plugin.rating) || 0)) + '%';
		stars.appendChild(fill);
		ratingItem.appendChild(stars);

		var ratingText = document.createElement('span');
		var starsOutOfFive = ((Number(plugin.rating) || 0) / 20).toFixed(1);
		ratingText.textContent = sprintf(
			strings.rating || '%1$s out of 5 stars (%2$s ratings)',
			starsOutOfFive,
			formatNumber(plugin.num_ratings || 0)
		);
		ratingItem.appendChild(ratingText);
		list.appendChild(ratingItem);

		return list;
	}

	function renderCompat(plugin) {
		var parts = [];
		if (plugin.requires) {
			parts.push(sprintf(strings.requiresWp || 'Requires WordPress %s', plugin.requires));
		}
		if (plugin.tested) {
			parts.push(sprintf(strings.testedWp || 'Tested up to %s', plugin.tested));
		}
		if (plugin.requires_php) {
			parts.push(sprintf(strings.requiresPhp || 'Requires PHP %s', plugin.requires_php));
		}

		var p = document.createElement('p');
		p.className = 'plugin-downloader-card-compat';
		p.textContent = parts.join(' · ');
		return p;
	}

	function renderActions(plugin) {
		var actions = document.createElement('div');
		actions.className = 'plugin-downloader-card-actions';
		actions.setAttribute('data-actions', plugin.slug || '');

		var compatible = plugin.compatible_wp !== false && plugin.compatible_php !== false;
		var network = !!config.isNetworkAdmin;
		var canActivate = !!config.canActivate && !network;
		var status = plugin.status || 'not_installed';

		actions.appendChild(
			actionButton('download', strings.download || 'Download', 'button', false)
		);

		if (status === 'active') {
			actions.appendChild(actionButton('noop', strings.active || 'Active', 'button', true));
		} else if (status === 'installed') {
			actions.appendChild(actionButton('noop', strings.alreadyInstalled || 'Already Installed', 'button', true));
			if (canActivate) {
				actions.appendChild(actionButton('activate', strings.activate || 'Activate', 'button-primary', false));
			}
		} else {
			var installDisabled = !compatible;
			actions.appendChild(actionButton('install', strings.install || 'Install', 'button', installDisabled));
			if (canActivate) {
				actions.appendChild(
					actionButton('install-activate', strings.installActivate || 'Install & Activate', 'button-primary', installDisabled)
				);
			}
		}

		var spin = document.createElement('span');
		spin.className = 'spinner';
		spin.hidden = true;
		actions.appendChild(spin);

		if (network && status !== 'active') {
			var note = document.createElement('span');
			note.className = 'plugin-downloader-card-compat';
			note.textContent = strings.networkNoActivate || '';
			actions.appendChild(note);
		}

		actions.addEventListener('click', function (event) {
			var button = event.target.closest('button[data-action]');
			if (!button || button.disabled) {
				return;
			}
			var action = button.getAttribute('data-action');
			if (!action || action === 'noop') {
				return;
			}
			handleAction(plugin.slug, action, cardFromSlug(plugin.slug));
		});

		return actions;
	}

	function actionButton(action, label, extraClass, disabled) {
		var button = document.createElement('button');
		button.type = 'button';
		button.className = 'button ' + extraClass;
		button.setAttribute('data-action', action);
		button.textContent = label;
		if (disabled) {
			button.disabled = true;
		}
		return button;
	}

	function handleAction(slug, action, card) {
		if (!slug || busySlugs[slug]) {
			return;
		}

		if (action === 'download') {
			downloadPlugin(slug, card);
			return;
		}

		if (action === 'install' || action === 'install-activate') {
			installPlugin(slug, card, action === 'install-activate');
			return;
		}

		if (action === 'activate') {
			activatePlugin(slug, card);
		}
	}

	function downloadPlugin(slug, card) {
		setCardBusy(card, true, strings.downloading || 'Preparing download…');

		post('plugin_downloader_download', { slug: slug })
			.then(function (payload) {
				setCardBusy(card, false);
				if (!payload || !payload.success || !payload.data || !payload.data.url) {
					showNotice('error', errorMessage(payload));
					return;
				}
				if (!isSafeDownloadUrl(payload.data.url)) {
					showNotice('error', strings.requestFailed || 'The request failed. Please try again.');
					return;
				}
				var link = document.createElement('a');
				link.href = payload.data.url;
				link.rel = 'noopener noreferrer';
				link.target = '_blank';
				document.body.appendChild(link);
				link.click();
				link.remove();
			})
			.catch(function (error) {
				setCardBusy(card, false);
				showNotice('error', interruptedOrFailed(error));
			});
	}

	function installPlugin(slug, card, activate) {
		setCardBusy(card, true, strings.installing || 'Installing…');
		if (activate) {
			updateBusyLabel(card, strings.installing || 'Installing…');
		}

		post('plugin_downloader_install', {
			slug: slug,
			activate: activate ? '1' : ''
		})
			.then(function (payload) {
				if (!payload || !payload.success) {
					setCardBusy(card, false);
					showNotice('error', errorMessage(payload));
					if (payload && payload.data && payload.data.status) {
						replaceCardActions(card, slug, payload.data.status);
					}
					return;
				}

				var status = payload.data && payload.data.status ? payload.data.status : (activate ? 'active' : 'installed');
				var message = payload.data && payload.data.message ? payload.data.message : (status === 'active' ? strings.installedActivated : strings.installed);
				setCardBusy(card, false);
				replaceCardActions(card, slug, status);
				showNotice('success', message);
			})
			.catch(function (error) {
				setCardBusy(card, false);
				showNotice('error', interruptedOrFailed(error));
			});
	}

	function activatePlugin(slug, card) {
		setCardBusy(card, true, strings.activating || 'Activating…');

		post('plugin_downloader_activate', { slug: slug })
			.then(function (payload) {
				setCardBusy(card, false);
				if (!payload || !payload.success) {
					showNotice('error', errorMessage(payload));
					return;
				}
				replaceCardActions(card, slug, 'active');
				showNotice('success', (payload.data && payload.data.message) || strings.activated);
			})
			.catch(function (error) {
				setCardBusy(card, false);
				showNotice('error', interruptedOrFailed(error));
			});
	}

	function replaceCardActions(card, slug, status) {
		if (!card) {
			return;
		}
		var old = card.querySelector('.plugin-downloader-card-actions');
		if (!old) {
			return;
		}
		var plugin = {
			slug: slug,
			status: status,
			compatible_wp: true,
			compatible_php: true
		};
		var next = renderActions(plugin);
		old.parentNode.replaceChild(next, old);
	}

	function setCardBusy(card, busy, label) {
		if (!card) {
			return;
		}
		var slug = card.getAttribute('data-slug') || '';
		if (busy) {
			busySlugs[slug] = true;
		} else {
			delete busySlugs[slug];
		}

		card.setAttribute('aria-busy', busy ? 'true' : 'false');
		var buttons = card.querySelectorAll('.plugin-downloader-card-actions button');
		for (var i = 0; i < buttons.length; i++) {
			buttons[i].disabled = busy || buttons[i].getAttribute('data-action') === 'noop';
		}

		var spin = card.querySelector('.plugin-downloader-card-actions .spinner');
		if (spin) {
			spin.hidden = !busy;
			if (busy) {
				spin.classList.add('is-active');
			} else {
				spin.classList.remove('is-active');
			}
		}

		if (busy && label) {
			updateBusyLabel(card, label);
		}
	}

	function updateBusyLabel(card, label) {
		var primary = card.querySelector('.plugin-downloader-card-actions button.button-primary:not([data-action="noop"])') ||
			card.querySelector('.plugin-downloader-card-actions button[data-action="install"]') ||
			card.querySelector('.plugin-downloader-card-actions button[data-action="activate"]');
		if (primary) {
			primary.textContent = label;
		}
	}

	function cardFromSlug(slug) {
		return document.querySelector('.plugin-downloader-card[data-slug="' + cssEscape(slug) + '"]');
	}

	function renderPagination(page, pages) {
		paginationEl.innerHTML = '';
		if (pages <= 1) {
			hidePagination();
			return;
		}

		paginationEl.hidden = false;

		var prev = document.createElement('button');
		prev.type = 'button';
		prev.className = 'button';
		prev.textContent = '← ' + (strings.previous || 'Previous');
		prev.disabled = page <= 1;
		prev.addEventListener('click', function () {
			if (page > 1) {
				runSearch(page - 1);
			}
		});

		var status = document.createElement('span');
		status.className = 'plugin-downloader-pagination-status';
		status.textContent = sprintf(strings.pageStatus || 'Page %1$s of %2$s', formatNumber(page), formatNumber(pages));

		var next = document.createElement('button');
		next.type = 'button';
		next.className = 'button';
		next.textContent = (strings.next || 'Next') + ' →';
		next.disabled = page >= pages;
		next.addEventListener('click', function () {
			if (page < pages) {
				runSearch(page + 1);
			}
		});

		paginationEl.appendChild(prev);
		paginationEl.appendChild(status);
		paginationEl.appendChild(next);
	}

	function hidePagination() {
		paginationEl.innerHTML = '';
		paginationEl.hidden = true;
	}

	function setSearching(isSearching) {
		submit.disabled = isSearching;
		spinner.hidden = !isSearching;
		if (isSearching) {
			spinner.classList.add('is-active');
		} else {
			spinner.classList.remove('is-active');
		}
		form.setAttribute('aria-busy', isSearching ? 'true' : 'false');
	}

	function setStatus(message, isError) {
		statusEl.textContent = message || '';
		if (isError) {
			statusEl.classList.add('is-error');
		} else {
			statusEl.classList.remove('is-error');
		}
	}

	function showNotice(type, message) {
		if (!noticesEl || !message) {
			return;
		}
		noticesEl.innerHTML = '';
		var notice = document.createElement('div');
		notice.className = 'notice notice-' + (type === 'success' ? 'success' : 'error') + ' is-dismissible';
		var p = document.createElement('p');
		p.textContent = message;
		notice.appendChild(p);

		var button = document.createElement('button');
		button.type = 'button';
		button.className = 'notice-dismiss';
		var sr = document.createElement('span');
		sr.className = 'screen-reader-text';
		sr.textContent = strings.dismissNotice || 'Dismiss this notice.';
		button.appendChild(sr);
		button.addEventListener('click', function () {
			notice.remove();
		});
		notice.appendChild(button);
		noticesEl.appendChild(notice);
	}

	function post(action, fields) {
		var body = new FormData();
		body.append('action', action);
		body.append('nonce', config.nonce || '');
		Object.keys(fields || {}).forEach(function (key) {
			body.append(key, fields[key]);
		});
		if (config.isNetworkAdmin) {
			body.append('network', '1');
		}

		return fetch(config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		}).then(parseJson);
	}

	function parseJson(response) {
		return response.text().then(function (text) {
			var data;
			try {
				data = text ? JSON.parse(text) : null;
			} catch (e) {
				data = null;
			}
			if (!data) {
				return {
					success: false,
					data: {
						message: strings.requestFailed || 'The request failed. Please try again.'
					}
				};
			}
			return data;
		});
	}

	function errorMessage(payload) {
		if (payload && payload.data && payload.data.message) {
			return payload.data.message;
		}
		return strings.requestFailed || 'The request failed. Please try again.';
	}

	function interruptedOrFailed(error) {
		if (error && error.name === 'AbortError') {
			return strings.requestInterrupted || 'The request was interrupted. Please try again.';
		}
		return strings.requestFailed || 'The request failed. Please try again.';
	}

	function warning(text) {
		var p = document.createElement('p');
		p.className = 'plugin-downloader-card-warning';
		p.textContent = text;
		return p;
	}

	function metaItem(text) {
		var li = document.createElement('li');
		li.textContent = text;
		return li;
	}

	function sprintf(format) {
		var args = Array.prototype.slice.call(arguments, 1);
		var sequential = 0;
		return String(format).replace(/%(\d+\$)?s/g, function (match, numbered) {
			if (numbered) {
				var index = parseInt(numbered, 10) - 1;
				return args[index] !== undefined ? String(args[index]) : match;
			}
			var value = args[sequential];
			sequential += 1;
			return value !== undefined ? String(value) : match;
		});
	}

	function formatNumber(value) {
		var number = Number(value) || 0;
		try {
			return number.toLocaleString();
		} catch (e) {
			return String(number);
		}
	}

	function isSafeIconUrl(url) {
		try {
			var parsed = new URL(url, window.location.href);
			if (parsed.protocol !== 'https:') {
				return false;
			}
			var host = parsed.hostname;
			return host === 'ps.w.org' || host === 's.w.org' || host === 'ts.w.org' || host.slice(-6) === '.w.org';
		} catch (e) {
			return false;
		}
	}

	function isSafeDownloadUrl(url) {
		try {
			var parsed = new URL(url, window.location.href);
			if (parsed.protocol !== 'https:') {
				return false;
			}
			return parsed.hostname === 'downloads.wordpress.org' || parsed.hostname === 'downloads.wp.org';
		} catch (e) {
			return false;
		}
	}

	function cssEscape(value) {
		if (window.CSS && typeof window.CSS.escape === 'function') {
			return window.CSS.escape(value);
		}
		return String(value).replace(/"/g, '\\"');
	}
})();
