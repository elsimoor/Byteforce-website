<?php
/**
 * Uninstall Plugin Downloader.
 *
 * Removes this plugin's options and transients only.
 * Does not deactivate, delete, or modify any other plugins.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Delete options and transients for the current site.
 *
 * @return void
 */
function plugin_downloader_uninstall_site() {
	delete_option( 'plugin_downloader_options' );

	global $wpdb;

	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_plugin_downloader_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_plugin_downloader_' ) . '%'
		)
	);
}

plugin_downloader_uninstall_site();

if ( is_multisite() ) {
	delete_site_option( 'plugin_downloader_options' );

	$site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $site_ids as $site_id ) {
		switch_to_blog( (int) $site_id );
		plugin_downloader_uninstall_site();
		restore_current_blog();
	}
}
