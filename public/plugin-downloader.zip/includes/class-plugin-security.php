<?php
/**
 * Security helpers for Plugin Downloader.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Input validation, capability checks, URL allowlists, and debug logging.
 */
class Plugin_Downloader_Security {

	/**
	 * Maximum length of a WordPress.org plugin slug.
	 *
	 * @var int
	 */
	const SLUG_MAX_LENGTH = 100;

	/**
	 * Maximum length of a search query.
	 *
	 * @var int
	 */
	const SEARCH_MAX_LENGTH = 100;

	/**
	 * Hosts allowed for plugin ZIP packages.
	 *
	 * @var string[]
	 */
	const DOWNLOAD_HOSTS = array(
		'downloads.wordpress.org',
		'downloads.wp.org',
	);

	/**
	 * Hosts allowed for plugin icons from the directory.
	 *
	 * @var string[]
	 */
	const ICON_HOSTS = array(
		'ps.w.org',
		's.w.org',
		'ts.w.org',
		'www.w.org',
		'w.org',
	);

	/**
	 * Validate a WordPress.org plugin slug.
	 *
	 * @param mixed $slug Raw slug.
	 * @return string Sanitized slug, or empty string if invalid.
	 */
	public static function sanitize_slug( $slug ) {
		if ( ! is_string( $slug ) ) {
			return '';
		}

		$slug = strtolower( trim( $slug ) );

		if ( '' === $slug || strlen( $slug ) > self::SLUG_MAX_LENGTH ) {
			return '';
		}

		if ( false !== strpos( $slug, '..' ) || false !== strpos( $slug, '/' ) || false !== strpos( $slug, '\\' ) || false !== strpos( $slug, ':' ) ) {
			return '';
		}

		if ( ! preg_match( '/^[a-z0-9][a-z0-9._-]*$/', $slug ) ) {
			return '';
		}

		return $slug;
	}

	/**
	 * Sanitize an installed plugin basename (e.g. akismet/akismet.php).
	 *
	 * @param mixed $plugin_file Raw plugin file.
	 * @return string Empty string if invalid.
	 */
	public static function sanitize_plugin_file( $plugin_file ) {
		if ( ! is_string( $plugin_file ) ) {
			return '';
		}

		$plugin_file = wp_unslash( $plugin_file );
		$plugin_file = str_replace( '\\', '/', $plugin_file );
		$plugin_file = ltrim( $plugin_file, '/' );

		if ( '' === $plugin_file || false !== strpos( $plugin_file, '..' ) || false !== strpos( $plugin_file, ':' ) ) {
			return '';
		}

		$plugin_file = plugin_basename( $plugin_file );

		if ( ! preg_match( '/^[a-zA-Z0-9][a-zA-Z0-9._\-\/]*\.php$/', $plugin_file ) ) {
			return '';
		}

		if ( strlen( $plugin_file ) > 200 ) {
			return '';
		}

		return $plugin_file;
	}

	/**
	 * Sanitize a search query.
	 *
	 * @param mixed $search Raw search.
	 * @return string
	 */
	public static function sanitize_search( $search ) {
		if ( ! is_string( $search ) && ! is_numeric( $search ) ) {
			return '';
		}

		$search = sanitize_text_field( (string) $search );
		$search = trim( $search );

		if ( strlen( $search ) > self::SEARCH_MAX_LENGTH ) {
			$search = substr( $search, 0, self::SEARCH_MAX_LENGTH );
		}

		return $search;
	}

	/**
	 * Whether the current user may install/download plugins.
	 *
	 * @return bool
	 */
	public static function current_user_can_install() {
		return current_user_can( 'install_plugins' );
	}

	/**
	 * Whether the current user may activate plugins on this site.
	 *
	 * @return bool
	 */
	public static function current_user_can_activate() {
		return current_user_can( 'activate_plugins' );
	}

	/**
	 * Whether the current user may change plugin settings.
	 *
	 * @return bool
	 */
	public static function current_user_can_manage_settings() {
		return current_user_can( 'install_plugins' );
	}

	/**
	 * Verify the AJAX nonce. Sends a JSON error and exits on failure.
	 *
	 * @return void
	 */
	public static function verify_ajax_nonce() {
		if ( ! check_ajax_referer( 'plugin_downloader_admin', 'nonce', false ) ) {
			self::log( 'AJAX request rejected: invalid nonce.' );
			wp_send_json_error(
				array(
					'code'    => 'invalid_nonce',
					'message' => __( 'Your session expired. Please refresh the page and try again.', 'plugin-downloader' ),
				),
				403
			);
		}
	}

	/**
	 * Require install_plugins. Sends a JSON error and exits on failure.
	 *
	 * @return void
	 */
	public static function require_install_cap() {
		if ( ! self::current_user_can_install() ) {
			self::log( 'AJAX request rejected: missing install_plugins capability.' );
			wp_send_json_error(
				array(
					'code'    => 'forbidden',
					'message' => __( 'You do not have permission to install plugins.', 'plugin-downloader' ),
				),
				403
			);
		}
	}

	/**
	 * Require activate_plugins. Sends a JSON error and exits on failure.
	 *
	 * @return void
	 */
	public static function require_activate_cap() {
		if ( ! self::current_user_can_activate() ) {
			self::log( 'AJAX request rejected: missing activate_plugins capability.' );
			wp_send_json_error(
				array(
					'code'    => 'forbidden',
					'message' => __( 'You do not have permission to activate plugins.', 'plugin-downloader' ),
				),
				403
			);
		}
	}

	/**
	 * Whether a URL is an official WordPress.org plugin ZIP.
	 *
	 * @param string $url URL to check.
	 * @return bool
	 */
	public static function is_allowed_download_url( $url ) {
		if ( ! is_string( $url ) || '' === $url ) {
			return false;
		}

		$url = esc_url_raw( $url, array( 'https' ) );
		if ( '' === $url ) {
			return false;
		}

		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) ) {
			return false;
		}

		if ( 'https' !== strtolower( $parts['scheme'] ) ) {
			return false;
		}

		$host = strtolower( $parts['host'] );

		if ( ! in_array( $host, self::DOWNLOAD_HOSTS, true ) ) {
			return false;
		}

		$path = isset( $parts['path'] ) ? $parts['path'] : '';
		if ( ! preg_match( '/^\/plugin\/[a-z0-9][a-z0-9._-]*(\.[0-9.]+)?\.zip$/i', $path ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Sanitize an icon URL from the WordPress.org plugin directory.
	 *
	 * @param mixed $url Raw URL.
	 * @return string Empty string if not allowed.
	 */
	public static function sanitize_icon_url( $url ) {
		if ( ! is_string( $url ) || '' === $url ) {
			return '';
		}

		$url = esc_url_raw( $url, array( 'https' ) );
		if ( '' === $url ) {
			return '';
		}

		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) ) {
			return '';
		}

		if ( 'https' !== strtolower( $parts['scheme'] ) ) {
			return '';
		}

		$host = strtolower( $parts['host'] );

		$allowed = false;
		foreach ( self::ICON_HOSTS as $allowed_host ) {
			if ( $host === $allowed_host || substr( $host, -1 * ( strlen( $allowed_host ) + 1 ) ) === '.' . $allowed_host ) {
				$allowed = true;
				break;
			}
		}

		if ( ! $allowed && ( 's.wordpress.org' === $host || 'ps.w.org' === $host ) ) {
			$allowed = true;
		}

		if ( ! $allowed ) {
			return '';
		}

		return $url;
	}

	/**
	 * Debug log. Writes only when WP_DEBUG is enabled.
	 *
	 * @param string $message Message to log.
	 * @return void
	 */
	public static function log( $message ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		if ( ! is_string( $message ) ) {
			return;
		}

		$message = preg_replace( '/(password|token|cookie|authorization|secret)=[^\s&]+/i', '$1=[redacted]', $message );

		error_log( '[Plugin Downloader] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	}
}
