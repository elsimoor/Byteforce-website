<?php
/**
 * Admin AJAX endpoints.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles search, download URL, install, and activate AJAX actions.
 */
class Plugin_Downloader_Ajax {

	/**
	 * Register AJAX actions. Logged-in users only.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'wp_ajax_plugin_downloader_search', array( $this, 'search' ) );
		add_action( 'wp_ajax_plugin_downloader_download', array( $this, 'download' ) );
		add_action( 'wp_ajax_plugin_downloader_install', array( $this, 'install' ) );
		add_action( 'wp_ajax_plugin_downloader_activate', array( $this, 'activate' ) );
	}

	/**
	 * Search WordPress.org plugins.
	 *
	 * @return void
	 */
	public function search() {
		Plugin_Downloader_Security::verify_ajax_nonce();
		Plugin_Downloader_Security::require_install_cap();

		$search   = isset( $_POST['search'] ) ? Plugin_Downloader_Security::sanitize_search( wp_unslash( $_POST['search'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$page     = isset( $_POST['page'] ) ? absint( wp_unslash( $_POST['page'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$per_page = Plugin_Downloader_Settings::get_per_page();

		$api    = new Plugin_Downloader_API();
		$result = $api->search( $search, $page, $per_page );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success( $result );
	}

	/**
	 * Return a verified official ZIP URL. The browser downloads it directly.
	 *
	 * @return void
	 */
	public function download() {
		Plugin_Downloader_Security::verify_ajax_nonce();
		Plugin_Downloader_Security::require_install_cap();

		$slug = isset( $_POST['slug'] ) ? Plugin_Downloader_Security::sanitize_slug( wp_unslash( $_POST['slug'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( '' === $slug ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_slug',
					'message' => __( 'The plugin slug is not valid.', 'plugin-downloader' ),
				),
				400
			);
		}

		$api = new Plugin_Downloader_API();
		$url = $api->get_verified_download_url( $slug );

		if ( is_wp_error( $url ) ) {
			wp_send_json_error(
				array(
					'code'    => $url->get_error_code(),
					'message' => $url->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'slug' => $slug,
				'url'  => $url,
			)
		);
	}

	/**
	 * Install a plugin from WordPress.org.
	 *
	 * @return void
	 */
	public function install() {
		Plugin_Downloader_Security::verify_ajax_nonce();
		Plugin_Downloader_Security::require_install_cap();

		$slug = isset( $_POST['slug'] ) ? Plugin_Downloader_Security::sanitize_slug( wp_unslash( $_POST['slug'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$activate = ! empty( $_POST['activate'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( '' === $slug ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_slug',
					'message' => __( 'The plugin slug is not valid.', 'plugin-downloader' ),
				),
				400
			);
		}

		$from_network = $this->request_from_network_admin();
		if ( ! empty( $_POST['network'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$from_network = true;
		}

		if ( $from_network ) {
			$activate = false;
		} elseif ( $activate ) {
			Plugin_Downloader_Security::require_activate_cap();
		} elseif ( Plugin_Downloader_Settings::get_auto_activate() && Plugin_Downloader_Security::current_user_can_activate() ) {
			$activate = true;
		}

		$installer = new Plugin_Downloader_Installer();
		$result    = $installer->install( $slug, $activate );

		if ( is_wp_error( $result ) ) {
			$status = 400;
			$code   = $result->get_error_code();
			if ( 'forbidden' === $code ) {
				$status = 403;
			}

			$data = array(
				'code'    => $code,
				'message' => $result->get_error_message(),
			);

			$error_data = $result->get_error_data();
			if ( is_array( $error_data ) ) {
				$data = array_merge( $data, $error_data );
			}

			$messages = $result->get_error_messages();
			if ( count( $messages ) > 1 ) {
				$data['message'] = implode( ' ', array_unique( $messages ) );
			}

			wp_send_json_error( $data, $status );
		}

		wp_send_json_success( $result );
	}

	/**
	 * Activate an installed plugin.
	 *
	 * @return void
	 */
	public function activate() {
		Plugin_Downloader_Security::verify_ajax_nonce();
		Plugin_Downloader_Security::require_install_cap();
		Plugin_Downloader_Security::require_activate_cap();

		$slug = isset( $_POST['slug'] ) ? Plugin_Downloader_Security::sanitize_slug( wp_unslash( $_POST['slug'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( '' === $slug ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_slug',
					'message' => __( 'The plugin slug is not valid.', 'plugin-downloader' ),
				),
				400
			);
		}

		if ( $this->request_from_network_admin() || ! empty( $_POST['network'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			wp_send_json_error(
				array(
					'code'    => 'network_activate_blocked',
					'message' => __( 'This plugin does not network-activate plugins. Activate it from the site Plugins screen instead.', 'plugin-downloader' ),
				),
				400
			);
		}

		$installer = new Plugin_Downloader_Installer();
		$result    = $installer->activate( $slug );

		if ( is_wp_error( $result ) ) {
			$status = 400;
			if ( 'forbidden' === $result->get_error_code() ) {
				$status = 403;
			}
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				$status
			);
		}

		wp_send_json_success( $result );
	}

	/**
	 * Detect network-admin origin. admin-ajax.php is never is_network_admin().
	 *
	 * @return bool
	 */
	private function request_from_network_admin() {
		if ( is_network_admin() ) {
			return true;
		}

		$referer = wp_get_referer();
		if ( $referer && false !== strpos( $referer, '/wp-admin/network/' ) ) {
			return true;
		}

		return false;
	}
}
