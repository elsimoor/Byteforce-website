<?php
/**
 * Settings API registration and option access.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin Downloader settings.
 */
class Plugin_Downloader_Settings {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	const OPTION = 'plugin_downloader_options';

	/**
	 * Settings group.
	 *
	 * @var string
	 */
	const GROUP = 'plugin_downloader';

	/**
	 * Allowed results-per-page values.
	 *
	 * @var int[]
	 */
	const PER_PAGE_OPTIONS = array( 10, 20, 30, 50 );

	/**
	 * Default results per page.
	 *
	 * @var int
	 */
	const DEFAULT_PER_PAGE = 20;

	/**
	 * Default API cache duration in seconds.
	 *
	 * @var int
	 */
	const DEFAULT_CACHE = 300;

	/**
	 * Register settings.
	 *
	 * @return void
	 */
	public function register() {
		register_setting(
			self::GROUP,
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_options' ),
				'default'           => self::defaults(),
				'show_in_rest'      => false,
			)
		);

		add_settings_section(
			'plugin_downloader_general',
			__( 'General', 'plugin-downloader' ),
			array( $this, 'render_section' ),
			'plugin-downloader-settings'
		);

		add_settings_field(
			'per_page',
			__( 'Results per page', 'plugin-downloader' ),
			array( $this, 'render_per_page_field' ),
			'plugin-downloader-settings',
			'plugin_downloader_general'
		);

		add_settings_field(
			'cache_duration',
			__( 'API cache duration', 'plugin-downloader' ),
			array( $this, 'render_cache_field' ),
			'plugin-downloader-settings',
			'plugin_downloader_general'
		);

		add_settings_field(
			'auto_activate',
			__( 'Automatic activation', 'plugin-downloader' ),
			array( $this, 'render_auto_activate_field' ),
			'plugin-downloader-settings',
			'plugin_downloader_general'
		);

		add_filter( 'option_page_capability_' . self::GROUP, array( $this, 'settings_capability' ) );
	}

	/**
	 * Capability required to save settings.
	 *
	 * @return string
	 */
	public function settings_capability() {
		return 'install_plugins';
	}

	/**
	 * Default options.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'per_page'        => self::DEFAULT_PER_PAGE,
			'cache_duration'  => self::DEFAULT_CACHE,
			'auto_activate'   => false,
		);
	}

	/**
	 * Get all options merged with defaults.
	 *
	 * @return array
	 */
	public static function get_options() {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		return wp_parse_args( $stored, self::defaults() );
	}

	/**
	 * Results per page.
	 *
	 * @return int
	 */
	public static function get_per_page() {
		$options = self::get_options();
		$per_page = isset( $options['per_page'] ) ? absint( $options['per_page'] ) : self::DEFAULT_PER_PAGE;
		if ( ! in_array( $per_page, self::PER_PAGE_OPTIONS, true ) ) {
			return self::DEFAULT_PER_PAGE;
		}
		return $per_page;
	}

	/**
	 * Cache duration in seconds.
	 *
	 * @return int
	 */
	public static function get_cache_duration() {
		$options  = self::get_options();
		$duration = isset( $options['cache_duration'] ) ? absint( $options['cache_duration'] ) : self::DEFAULT_CACHE;
		if ( $duration > 86400 ) {
			$duration = 86400;
		}
		return $duration;
	}

	/**
	 * Whether Install should also activate.
	 *
	 * @return bool
	 */
	public static function get_auto_activate() {
		$options = self::get_options();
		return ! empty( $options['auto_activate'] );
	}

	/**
	 * Sanitize options from the Settings API.
	 *
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public function sanitize_options( $input ) {
		$defaults = self::defaults();
		$output   = $defaults;

		if ( ! is_array( $input ) ) {
			return $output;
		}

		if ( isset( $input['per_page'] ) ) {
			$per_page = absint( $input['per_page'] );
			if ( in_array( $per_page, self::PER_PAGE_OPTIONS, true ) ) {
				$output['per_page'] = $per_page;
			}
		}

		if ( isset( $input['cache_duration'] ) ) {
			$duration = absint( $input['cache_duration'] );
			if ( $duration > 86400 ) {
				$duration = 86400;
			}
			$output['cache_duration'] = $duration;
		}

		$output['auto_activate'] = ! empty( $input['auto_activate'] );

		$previous = self::get_options();
		if ( (int) $previous['cache_duration'] !== (int) $output['cache_duration'] ) {
			Plugin_Downloader_API::delete_transients();
		}

		return $output;
	}

	/**
	 * Section description.
	 *
	 * @return void
	 */
	public function render_section() {
		echo '<p>' . esc_html__( 'These settings apply to Plugin Downloader search and installation.', 'plugin-downloader' ) . '</p>';
	}

	/**
	 * Results per page field.
	 *
	 * @return void
	 */
	public function render_per_page_field() {
		$current = self::get_per_page();
		echo '<select name="' . esc_attr( self::OPTION ) . '[per_page]" id="plugin_downloader_per_page">';
		foreach ( self::PER_PAGE_OPTIONS as $value ) {
			printf(
				'<option value="%1$d"%2$s>%1$d</option>',
				(int) $value,
				selected( $current, $value, false )
			);
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'Number of WordPress.org plugins to show on each search page.', 'plugin-downloader' ) . '</p>';
	}

	/**
	 * Cache duration field.
	 *
	 * @return void
	 */
	public function render_cache_field() {
		$current = self::get_cache_duration();
		printf(
			'<input name="%1$s[cache_duration]" id="plugin_downloader_cache_duration" type="number" class="small-text" min="0" max="86400" step="1" value="%2$d" />',
			esc_attr( self::OPTION ),
			(int) $current
		);
		echo '<p class="description">' . esc_html__( 'How long to cache WordPress.org search results, in seconds. Default is 300 (5 minutes). Use 0 to disable caching. Plugin details are cached for at least one hour when caching is enabled.', 'plugin-downloader' ) . '</p>';
	}

	/**
	 * Auto-activate field.
	 *
	 * @return void
	 */
	public function render_auto_activate_field() {
		$checked = self::get_auto_activate();
		printf(
			'<label for="plugin_downloader_auto_activate"><input name="%1$s[auto_activate]" id="plugin_downloader_auto_activate" type="checkbox" value="1"%2$s /> %3$s</label>',
			esc_attr( self::OPTION ),
			checked( $checked, true, false ),
			esc_html__( 'Automatically activate plugins after installation', 'plugin-downloader' )
		);
		echo '<p class="description">' . esc_html__( 'When enabled, the Install button also activates the plugin. This never network-activates plugins on Multisite.', 'plugin-downloader' ) . '</p>';
	}
}
