<?php
/**
 * Plugin installation and activation using WordPress native APIs.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installs and activates plugins from verified WordPress.org packages.
 */
class Plugin_Downloader_Installer {

	/**
	 * Get local install/activation status for a slug.
	 *
	 * @param string $slug Plugin slug.
	 * @return array { status: string, plugin_file: string }
	 */
	public function get_local_status( $slug ) {
		$slug = Plugin_Downloader_Security::sanitize_slug( $slug );
		$file = $this->get_plugin_file_by_slug( $slug );

		if ( '' === $file ) {
			return array(
				'status'      => 'not_installed',
				'plugin_file' => '',
			);
		}

		$status = 'installed';
		if ( $this->is_plugin_active_anywhere( $file ) ) {
			$status = 'active';
		}

		return array(
			'status'      => $status,
			'plugin_file' => $file,
		);
	}

	/**
	 * Find the main plugin file for a directory slug.
	 *
	 * Does not assume slug.php is the bootstrap file.
	 *
	 * @param string $slug Plugin slug.
	 * @return string Plugin basename (e.g. elementor/elementor.php) or empty.
	 */
	public function get_plugin_file_by_slug( $slug ) {
		$slug = Plugin_Downloader_Security::sanitize_slug( $slug );
		if ( '' === $slug ) {
			return '';
		}

		$this->load_plugin_functions();

		$plugins    = get_plugins();
		$candidates = array();

		foreach ( $plugins as $file => $data ) {
			$dir = dirname( $file );

			if ( $dir === $slug ) {
				$candidates[] = $file;
				continue;
			}

			if ( '.' === $dir && basename( $file, '.php' ) === $slug ) {
				$candidates[] = $file;
			}
		}

		if ( empty( $candidates ) ) {
			return '';
		}

		$preferred = $slug . '/' . $slug . '.php';
		if ( in_array( $preferred, $candidates, true ) ) {
			return $preferred;
		}

		return $candidates[0];
	}

	/**
	 * Install a plugin from WordPress.org, optionally activating it.
	 *
	 * @param string $slug     Plugin slug.
	 * @param bool   $activate Whether to activate after install.
	 * @return array|WP_Error Result payload on success.
	 */
	public function install( $slug, $activate = false ) {
		$slug = Plugin_Downloader_Security::sanitize_slug( $slug );
		if ( '' === $slug ) {
			return new WP_Error(
				'invalid_slug',
				__( 'The plugin slug is not valid.', 'plugin-downloader' )
			);
		}

		if ( ! Plugin_Downloader_Security::current_user_can_install() ) {
			return new WP_Error(
				'forbidden',
				__( 'You do not have permission to install plugins.', 'plugin-downloader' )
			);
		}

		if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
			return new WP_Error(
				'file_mods_disabled',
				__( 'Plugin installation is disabled on this site.', 'plugin-downloader' )
			);
		}

		$local = $this->get_local_status( $slug );

		if ( 'active' === $local['status'] ) {
			return array(
				'slug'        => $slug,
				'status'      => 'active',
				'plugin_file' => $local['plugin_file'],
				'message'     => __( 'This plugin is already active.', 'plugin-downloader' ),
			);
		}

		if ( 'installed' === $local['status'] ) {
			if ( $activate ) {
				return $this->activate( $slug );
			}

			return new WP_Error(
				'already_installed',
				__( 'The plugin is already installed.', 'plugin-downloader' ),
				array(
					'slug'        => $slug,
					'status'      => 'installed',
					'plugin_file' => $local['plugin_file'],
				)
			);
		}

		$api    = new Plugin_Downloader_API();
		$plugin = $api->get_plugin( $slug );
		if ( is_wp_error( $plugin ) ) {
			return $plugin;
		}

		$compat = $this->check_requirements( $plugin );
		if ( is_wp_error( $compat ) ) {
			return $compat;
		}

		$package = $api->get_verified_download_url( $slug );
		if ( is_wp_error( $package ) ) {
			return $package;
		}

		$fs = $this->ensure_filesystem();
		if ( is_wp_error( $fs ) ) {
			return $fs;
		}

		$this->load_upgrader();

		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );

		ob_start();
		$result = $upgrader->install(
			$package,
			array(
				'overwrite_package'  => false,
				'clear_update_cache' => true,
			)
		);
		$buffered = ob_get_clean();
		if ( $buffered ) {
			Plugin_Downloader_Security::log( 'Upgrader buffer: ' . substr( wp_strip_all_tags( $buffered ), 0, 200 ) );
		}

		if ( is_wp_error( $result ) ) {
			Plugin_Downloader_Security::log( 'Install failed for ' . $slug . ': ' . $result->get_error_code() );
			return $this->friendly_install_error( $result );
		}

		$skin_errors = $skin->get_errors();
		if ( is_wp_error( $skin_errors ) && $skin_errors->has_errors() ) {
			Plugin_Downloader_Security::log( 'Install skin errors for ' . $slug . ': ' . $skin_errors->get_error_code() );
			return $this->friendly_install_error( $skin_errors );
		}

		if ( false === $result ) {
			return new WP_Error(
				'install_failed',
				__( 'The plugin could not be downloaded.', 'plugin-downloader' )
			);
		}

		wp_clean_plugins_cache( true );

		$plugin_file = $upgrader->plugin_info();
		if ( ! $plugin_file ) {
			$plugin_file = $this->get_plugin_file_by_slug( $slug );
		}

		if ( ! $plugin_file ) {
			return new WP_Error(
				'install_failed',
				__( 'The plugin was downloaded but WordPress could not determine the main plugin file.', 'plugin-downloader' )
			);
		}

		Plugin_Downloader_Security::log( 'Installed plugin ' . $slug . ' as ' . $plugin_file );

		if ( $activate ) {
			$activated = $this->activate_file( $plugin_file );
			if ( is_wp_error( $activated ) ) {
				$activated->add(
					'installed_not_activated',
					__( 'The plugin was installed but could not be activated.', 'plugin-downloader' )
				);
				return $activated;
			}

			return array(
				'slug'        => $slug,
				'status'      => 'active',
				'plugin_file' => $plugin_file,
				'message'     => __( 'Plugin installed and activated.', 'plugin-downloader' ),
			);
		}

		return array(
			'slug'        => $slug,
			'status'      => 'installed',
			'plugin_file' => $plugin_file,
			'message'     => __( 'Plugin installed.', 'plugin-downloader' ),
		);
	}

	/**
	 * Activate an already-installed plugin by slug.
	 *
	 * @param string $slug Plugin slug.
	 * @return array|WP_Error
	 */
	public function activate( $slug ) {
		$slug = Plugin_Downloader_Security::sanitize_slug( $slug );
		if ( '' === $slug ) {
			return new WP_Error(
				'invalid_slug',
				__( 'The plugin slug is not valid.', 'plugin-downloader' )
			);
		}

		if ( ! Plugin_Downloader_Security::current_user_can_activate() ) {
			return new WP_Error(
				'forbidden',
				__( 'You do not have permission to activate plugins.', 'plugin-downloader' )
			);
		}

		if ( is_network_admin() ) {
			return new WP_Error(
				'network_activate_blocked',
				__( 'This plugin does not network-activate plugins. Activate it from the site Plugins screen instead.', 'plugin-downloader' )
			);
		}

		$plugin_file = $this->get_plugin_file_by_slug( $slug );
		if ( '' === $plugin_file ) {
			return new WP_Error(
				'not_installed',
				__( 'The plugin is not installed.', 'plugin-downloader' )
			);
		}

		if ( $this->is_plugin_active_anywhere( $plugin_file ) ) {
			return array(
				'slug'        => $slug,
				'status'      => 'active',
				'plugin_file' => $plugin_file,
				'message'     => __( 'This plugin is already active.', 'plugin-downloader' ),
			);
		}

		$activated = $this->activate_file( $plugin_file );
		if ( is_wp_error( $activated ) ) {
			return $activated;
		}

		return array(
			'slug'        => $slug,
			'status'      => 'active',
			'plugin_file' => $plugin_file,
			'message'     => __( 'Plugin activated.', 'plugin-downloader' ),
		);
	}

	/**
	 * Activate a plugin file without network-activating it.
	 *
	 * @param string $plugin_file Plugin basename.
	 * @return true|WP_Error
	 */
	private function activate_file( $plugin_file ) {
		$this->load_plugin_functions();

		if ( is_network_admin() ) {
			return new WP_Error(
				'network_activate_blocked',
				__( 'This plugin does not network-activate plugins. Activate it from the site Plugins screen instead.', 'plugin-downloader' )
			);
		}

		$result = activate_plugin( $plugin_file, '', false, false );

		if ( is_wp_error( $result ) ) {
			Plugin_Downloader_Security::log( 'Activation failed for ' . $plugin_file . ': ' . $result->get_error_code() );
			return new WP_Error(
				'activation_failed',
				sprintf(
					/* translators: %s: error message from WordPress */
					__( 'The plugin was installed but could not be activated. %s', 'plugin-downloader' ),
					$result->get_error_message()
				)
			);
		}

		if ( ! is_plugin_active( $plugin_file ) ) {
			return new WP_Error(
				'activation_failed',
				__( 'The plugin was installed but could not be activated.', 'plugin-downloader' )
			);
		}

		Plugin_Downloader_Security::log( 'Activated plugin ' . $plugin_file );

		return true;
	}

	/**
	 * Check WP/PHP requirements before installing.
	 *
	 * @param array $plugin Prepared plugin data.
	 * @return true|WP_Error
	 */
	private function check_requirements( $plugin ) {
		if ( empty( $plugin['compatible_wp'] ) ) {
			return new WP_Error(
				'wp_incompatible',
				sprintf(
					/* translators: %s: required WordPress version */
					__( 'This plugin requires WordPress %s or higher.', 'plugin-downloader' ),
					isset( $plugin['requires'] ) ? $plugin['requires'] : ''
				)
			);
		}

		if ( empty( $plugin['compatible_php'] ) ) {
			return new WP_Error(
				'php_incompatible',
				sprintf(
					/* translators: %s: required PHP version */
					__( 'This plugin requires PHP %s or higher.', 'plugin-downloader' ),
					isset( $plugin['requires_php'] ) ? $plugin['requires_php'] : ''
				)
			);
		}

		return true;
	}

	/**
	 * Ensure the WordPress filesystem is available for plugin writes.
	 *
	 * @return true|WP_Error
	 */
	private function ensure_filesystem() {
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		if ( ! WP_Filesystem() ) {
			return new WP_Error(
				'fs_unavailable',
				__( 'The WordPress filesystem is not writable.', 'plugin-downloader' )
			);
		}

		global $wp_filesystem;
		if ( ! $wp_filesystem || ! $wp_filesystem->is_writable( WP_PLUGIN_DIR ) ) {
			return new WP_Error(
				'fs_unavailable',
				__( 'The WordPress filesystem is not writable.', 'plugin-downloader' )
			);
		}

		return true;
	}

	/**
	 * Map upgrader errors to human-readable messages.
	 *
	 * @param WP_Error $error Upgrader error.
	 * @return WP_Error
	 */
	private function friendly_install_error( $error ) {
		$code = $error->get_error_code();

		$map = array(
			'folder_exists'          => __( 'The plugin is already installed.', 'plugin-downloader' ),
			'incompatible_archive'   => __( 'The plugin ZIP file is invalid and could not be installed.', 'plugin-downloader' ),
			'incompatible_archive_reason' => __( 'The plugin ZIP file is invalid and could not be installed.', 'plugin-downloader' ),
			'empty_archive'          => __( 'The plugin ZIP file is invalid and could not be installed.', 'plugin-downloader' ),
			'fs_unavailable'         => __( 'The WordPress filesystem is not writable.', 'plugin-downloader' ),
			'fs_error'               => __( 'The WordPress filesystem is not writable.', 'plugin-downloader' ),
			'fs_no_root_dir'         => __( 'The WordPress filesystem is not writable.', 'plugin-downloader' ),
			'fs_no_content_dir'      => __( 'The WordPress filesystem is not writable.', 'plugin-downloader' ),
			'fs_no_plugins_dir'      => __( 'The WordPress filesystem is not writable.', 'plugin-downloader' ),
			'fs_no_folder'           => __( 'The WordPress filesystem is not writable.', 'plugin-downloader' ),
			'download_failed'        => __( 'The plugin could not be downloaded.', 'plugin-downloader' ),
			'no_package'             => __( 'The plugin could not be downloaded.', 'plugin-downloader' ),
			'package_source_empty'   => __( 'The plugin ZIP file is invalid and could not be installed.', 'plugin-downloader' ),
		);

		if ( isset( $map[ $code ] ) ) {
			return new WP_Error( $code, $map[ $code ] );
		}

		return new WP_Error(
			'install_failed',
			__( 'The plugin could not be downloaded.', 'plugin-downloader' )
		);
	}

	/**
	 * Whether a plugin is active on this site or network-wide.
	 *
	 * @param string $plugin_file Plugin basename.
	 * @return bool
	 */
	private function is_plugin_active_anywhere( $plugin_file ) {
		$this->load_plugin_functions();

		if ( is_plugin_active( $plugin_file ) ) {
			return true;
		}

		if ( is_multisite() && is_plugin_active_for_network( $plugin_file ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Load plugin.php helpers.
	 *
	 * @return void
	 */
	private function load_plugin_functions() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
	}

	/**
	 * Load upgrader classes only when installing.
	 *
	 * @return void
	 */
	private function load_upgrader() {
		if ( ! class_exists( 'WP_Upgrader' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		}
		if ( ! class_exists( 'Plugin_Upgrader' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-plugin-upgrader.php';
		}
		if ( ! class_exists( 'WP_Ajax_Upgrader_Skin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php';
		}
		if ( ! function_exists( 'request_filesystem_credentials' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
	}
}
