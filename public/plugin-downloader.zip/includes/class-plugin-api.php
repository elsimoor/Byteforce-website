<?php
/**
 * WordPress.org Plugin Directory API client.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Talks to the official WordPress.org Plugin API with caching and validation.
 */
class Plugin_Downloader_API {

	/**
	 * Official Plugin API endpoint.
	 *
	 * @var string
	 */
	const API_URL = 'https://api.wordpress.org/plugins/info/1.2/';

	/**
	 * HTTP timeout in seconds.
	 *
	 * @var int
	 */
	const TIMEOUT = 15;

	/**
	 * Default plugin-info cache lifetime (1 hour).
	 *
	 * @var int
	 */
	const INFO_CACHE_TTL = 3600;

	/**
	 * Search the WordPress.org Plugin Directory.
	 *
	 * @param string $search   Search term.
	 * @param int    $page     Page number (1-based).
	 * @param int    $per_page Results per page.
	 * @return array|WP_Error {
	 *     @type array $plugins Prepared plugin rows.
	 *     @type array $info    Pagination info.
	 * }
	 */
	public function search( $search, $page = 1, $per_page = 20 ) {
		$search = Plugin_Downloader_Security::sanitize_search( $search );
		if ( '' === $search ) {
			return new WP_Error(
				'empty_search',
				__( 'Please enter a search term.', 'plugin-downloader' )
			);
		}

		$page     = max( 1, absint( $page ) );
		$per_page = $this->normalize_per_page( $per_page );

		$cache_key = $this->search_cache_key( $search, $page, $per_page );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) && isset( $cached['plugins'], $cached['info'] ) ) {
			$cached['plugins'] = $this->enrich_local_status( $cached['plugins'] );
			return $cached;
		}

		$this->load_plugin_install_api();

		$api = plugins_api(
			'query_plugins',
			array(
				'search'   => $search,
				'page'     => $page,
				'per_page' => $per_page,
				'fields'   => $this->search_fields(),
			)
		);

		if ( is_wp_error( $api ) ) {
			Plugin_Downloader_Security::log( 'Search API error: ' . $api->get_error_code() );
			return $this->friendly_api_error( $api );
		}

		if ( ! is_object( $api ) || ! isset( $api->plugins ) || ! is_array( $api->plugins ) ) {
			Plugin_Downloader_Security::log( 'Search API returned a malformed payload.' );
			return new WP_Error(
				'invalid_response',
				__( 'WordPress.org returned an unexpected response. Please try again.', 'plugin-downloader' )
			);
		}

		$plugins = array();
		foreach ( $api->plugins as $plugin ) {
			$prepared = $this->prepare_plugin( $plugin );
			if ( ! empty( $prepared ) ) {
				$plugins[] = $prepared;
			}
		}

		$info = array(
			'page'    => $page,
			'pages'   => isset( $api->info['pages'] ) ? max( 1, absint( $api->info['pages'] ) ) : 1,
			'results' => isset( $api->info['results'] ) ? absint( $api->info['results'] ) : count( $plugins ),
		);

		$result = array(
			'plugins' => $plugins,
			'info'    => $info,
		);

		$ttl = Plugin_Downloader_Settings::get_cache_duration();
		if ( $ttl > 0 ) {
			set_transient( $cache_key, $result, $ttl );
		}

		$result['plugins'] = $this->enrich_local_status( $result['plugins'] );

		return $result;
	}

	/**
	 * Fetch official plugin information by slug.
	 *
	 * @param string $slug Plugin slug.
	 * @return array|WP_Error Prepared plugin data.
	 */
	public function get_plugin( $slug ) {
		$slug = Plugin_Downloader_Security::sanitize_slug( $slug );
		if ( '' === $slug ) {
			return new WP_Error(
				'invalid_slug',
				__( 'The plugin slug is not valid.', 'plugin-downloader' )
			);
		}

		$cache_key = 'plugin_downloader_info_' . md5( $slug );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) && ! empty( $cached['slug'] ) && $cached['slug'] === $slug ) {
			return $this->enrich_local_status( array( $cached ) )[0];
		}

		$this->load_plugin_install_api();

		$api = plugins_api(
			'plugin_information',
			array(
				'slug'   => $slug,
				'fields' => $this->info_fields(),
			)
		);

		if ( is_wp_error( $api ) ) {
			Plugin_Downloader_Security::log( 'Plugin info API error for slug ' . $slug . ': ' . $api->get_error_code() );
			return $this->friendly_api_error( $api, true );
		}

		if ( ! is_object( $api ) ) {
			Plugin_Downloader_Security::log( 'Plugin info API returned a malformed payload for slug ' . $slug );
			return new WP_Error(
				'invalid_response',
				__( 'WordPress.org returned an unexpected response. Please try again.', 'plugin-downloader' )
			);
		}

		$prepared = $this->prepare_plugin( $api );
		if ( empty( $prepared ) ) {
			return new WP_Error(
				'plugin_not_found',
				__( 'This plugin could not be found on WordPress.org.', 'plugin-downloader' )
			);
		}

		$ttl = max( self::INFO_CACHE_TTL, Plugin_Downloader_Settings::get_cache_duration() );
		if ( Plugin_Downloader_Settings::get_cache_duration() > 0 ) {
			set_transient( $cache_key, $prepared, $ttl );
		}

		return $this->enrich_local_status( array( $prepared ) )[0];
	}

	/**
	 * Return a verified official ZIP URL for a slug.
	 *
	 * @param string $slug Plugin slug.
	 * @return string|WP_Error
	 */
	public function get_verified_download_url( $slug ) {
		$plugin = $this->get_plugin( $slug );
		if ( is_wp_error( $plugin ) ) {
			return $plugin;
		}

		if ( empty( $plugin['download_url'] ) || ! Plugin_Downloader_Security::is_allowed_download_url( $plugin['download_url'] ) ) {
			return new WP_Error(
				'invalid_download',
				__( 'The plugin could not be downloaded.', 'plugin-downloader' )
			);
		}

		return $plugin['download_url'];
	}

	/**
	 * Delete this plugin's transients.
	 *
	 * @return void
	 */
	public static function delete_transients() {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_plugin_downloader_' ) . '%',
				$wpdb->esc_like( '_transient_timeout_plugin_downloader_' ) . '%'
			)
		);
	}

	/**
	 * Fields requested for search results.
	 *
	 * @return array
	 */
	private function search_fields() {
		return array(
			'short_description' => true,
			'description'       => false,
			'sections'          => false,
			'tested'            => true,
			'requires'          => true,
			'requires_php'      => true,
			'rating'            => true,
			'ratings'           => false,
			'downloaded'        => false,
			'downloadlink'      => true,
			'last_updated'      => true,
			'added'             => false,
			'tags'              => false,
			'homepage'          => false,
			'donate_link'       => false,
			'reviews'           => false,
			'banners'           => false,
			'icons'             => true,
			'active_installs'   => true,
			'group'             => false,
			'contributors'      => false,
		);
	}

	/**
	 * Fields requested for plugin information.
	 *
	 * @return array
	 */
	private function info_fields() {
		$fields                     = $this->search_fields();
		$fields['short_description'] = true;
		$fields['downloadlink']     = true;
		$fields['versions']         = false;
		$fields['screenshots']      = false;
		return $fields;
	}

	/**
	 * Normalize a plugin object from the API into a safe array.
	 *
	 * @param object|array $plugin Raw API plugin.
	 * @return array Empty array if the plugin cannot be used.
	 */
	private function prepare_plugin( $plugin ) {
		if ( is_array( $plugin ) ) {
			$plugin = (object) $plugin;
		}

		if ( ! is_object( $plugin ) || empty( $plugin->slug ) ) {
			return array();
		}

		$slug = Plugin_Downloader_Security::sanitize_slug( $plugin->slug );
		if ( '' === $slug ) {
			return array();
		}

		$name = isset( $plugin->name ) ? $this->clean_text( $plugin->name ) : $slug;
		if ( '' === $name ) {
			$name = $slug;
		}

		$author = '';
		if ( isset( $plugin->author ) ) {
			$author = $this->clean_text( $plugin->author );
		}

		$description = '';
		if ( isset( $plugin->short_description ) ) {
			$description = $this->clean_text( $plugin->short_description );
		}

		$version = isset( $plugin->version ) ? $this->clean_text( $plugin->version ) : '';
		$requires = isset( $plugin->requires ) ? $this->clean_text( $plugin->requires ) : '';
		$tested    = isset( $plugin->tested ) ? $this->clean_text( $plugin->tested ) : '';
		$requires_php = isset( $plugin->requires_php ) ? $this->clean_text( $plugin->requires_php ) : '';

		$download_url = '';
		if ( ! empty( $plugin->download_link ) && Plugin_Downloader_Security::is_allowed_download_url( $plugin->download_link ) ) {
			$download_url = esc_url_raw( $plugin->download_link, array( 'https' ) );
		}

		$icon = $this->extract_icon( $plugin );

		$rating      = isset( $plugin->rating ) ? min( 100, max( 0, (float) $plugin->rating ) ) : 0;
		$num_ratings = isset( $plugin->num_ratings ) ? absint( $plugin->num_ratings ) : 0;
		$installs    = isset( $plugin->active_installs ) ? absint( $plugin->active_installs ) : 0;

		$last_updated_raw = isset( $plugin->last_updated ) ? $this->clean_text( $plugin->last_updated ) : '';
		$last_updated     = $this->format_last_updated( $last_updated_raw );

		$wp_ok  = $this->is_wp_compatible( $requires );
		$php_ok = $this->is_php_compatible( $requires_php );

		return array(
			'slug'                 => $slug,
			'name'                 => $name,
			'author'               => $author,
			'short_description'    => $description,
			'version'              => $version,
			'requires'             => $requires,
			'tested'               => $tested,
			'requires_php'         => $requires_php,
			'rating'               => $rating,
			'num_ratings'          => $num_ratings,
			'active_installs'      => $installs,
			'active_installs_text' => $this->format_installs( $installs ),
			'last_updated'         => $last_updated,
			'icon'                 => $icon,
			'download_url'         => $download_url,
			'compatible_wp'        => $wp_ok,
			'compatible_php'       => $php_ok,
			'status'               => 'not_installed',
			'plugin_file'          => '',
		);
	}

	/**
	 * Attach local install/active state. Never cached as it is site-specific.
	 *
	 * @param array $plugins Prepared plugins.
	 * @return array
	 */
	private function enrich_local_status( $plugins ) {
		$installer = new Plugin_Downloader_Installer();

		foreach ( $plugins as $index => $plugin ) {
			if ( empty( $plugin['slug'] ) ) {
				continue;
			}
			$local                         = $installer->get_local_status( $plugin['slug'] );
			$plugins[ $index ]['status']      = $local['status'];
			$plugins[ $index ]['plugin_file'] = $local['plugin_file'];
		}

		return $plugins;
	}

	/**
	 * Extract a safe icon URL.
	 *
	 * @param object $plugin API plugin.
	 * @return string
	 */
	private function extract_icon( $plugin ) {
		if ( empty( $plugin->icons ) || ! is_array( $plugin->icons ) ) {
			return '';
		}

		foreach ( array( '2x', '1x', 'default', 'svg' ) as $size ) {
			if ( empty( $plugin->icons[ $size ] ) ) {
				continue;
			}
			$icon = Plugin_Downloader_Security::sanitize_icon_url( $plugin->icons[ $size ] );
			if ( '' !== $icon ) {
				return $icon;
			}
		}

		return '';
	}

	/**
	 * Strip tags and decode entities from API text.
	 *
	 * @param mixed $text Raw text.
	 * @return string
	 */
	private function clean_text( $text ) {
		if ( ! is_string( $text ) && ! is_numeric( $text ) ) {
			return '';
		}

		$text = html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' );
		$text = wp_strip_all_tags( $text );
		$text = trim( $text );

		return $text;
	}

	/**
	 * Human-readable last-updated string.
	 *
	 * @param string $raw API timestamp.
	 * @return string
	 */
	private function format_last_updated( $raw ) {
		if ( '' === $raw ) {
			return '';
		}

		$timestamp = strtotime( $raw );
		if ( ! $timestamp ) {
			return $raw;
		}

		return sprintf(
			/* translators: %s: human-readable time difference */
			__( '%s ago', 'plugin-downloader' ),
			human_time_diff( $timestamp, time() )
		);
	}

	/**
	 * Format active install counts the way WordPress.org does.
	 *
	 * @param int $installs Count.
	 * @return string
	 */
	private function format_installs( $installs ) {
		$installs = absint( $installs );

		if ( $installs >= 1000000 ) {
			$millions = floor( $installs / 1000000 );
			return sprintf(
				/* translators: %s: number of millions of installs */
				_n( '%s+ million', '%s+ million', $millions, 'plugin-downloader' ),
				number_format_i18n( $millions )
			);
		}

		if ( $installs >= 10000 ) {
			return sprintf(
				/* translators: %s: number of active installs */
				__( '%s+', 'plugin-downloader' ),
				number_format_i18n( floor( $installs / 10000 ) * 10000 )
			);
		}

		if ( $installs >= 1000 ) {
			return sprintf(
				/* translators: %s: number of active installs */
				__( '%s+', 'plugin-downloader' ),
				number_format_i18n( floor( $installs / 1000 ) * 1000 )
			);
		}

		return number_format_i18n( $installs );
	}

	/**
	 * Whether the current WordPress version meets the plugin requirement.
	 *
	 * @param string $requires Required WP version.
	 * @return bool
	 */
	private function is_wp_compatible( $requires ) {
		if ( '' === $requires ) {
			return true;
		}

		return version_compare( get_bloginfo( 'version' ), $requires, '>=' );
	}

	/**
	 * Whether the current PHP version meets the plugin requirement.
	 *
	 * @param string $requires_php Required PHP version.
	 * @return bool
	 */
	private function is_php_compatible( $requires_php ) {
		if ( '' === $requires_php ) {
			return true;
		}

		return version_compare( PHP_VERSION, $requires_php, '>=' );
	}

	/**
	 * Allowed per-page values.
	 *
	 * @param int $per_page Requested size.
	 * @return int
	 */
	private function normalize_per_page( $per_page ) {
		$allowed = Plugin_Downloader_Settings::PER_PAGE_OPTIONS;
		$per_page = absint( $per_page );
		if ( ! in_array( $per_page, $allowed, true ) ) {
			return Plugin_Downloader_Settings::get_per_page();
		}
		return $per_page;
	}

	/**
	 * Cache key for a search. Uses a hash so keys stay short and bounded.
	 *
	 * @param string $search   Normalized search.
	 * @param int    $page     Page.
	 * @param int    $per_page Per page.
	 * @return string
	 */
	private function search_cache_key( $search, $page, $per_page ) {
		$locale = determine_locale();
		$hash   = md5( strtolower( $search ) . '|' . $page . '|' . $per_page . '|' . $locale );
		return 'plugin_downloader_search_' . $hash;
	}

	/**
	 * Load WordPress plugin-install API helpers.
	 *
	 * @return void
	 */
	private function load_plugin_install_api() {
		if ( ! function_exists( 'plugins_api' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		}
	}

	/**
	 * Map a WP_Error from plugins_api() to a user-facing message.
	 *
	 * @param WP_Error $error        Original error.
	 * @param bool     $is_not_found Whether this was a single-plugin lookup.
	 * @return WP_Error
	 */
	private function friendly_api_error( $error, $is_not_found = false ) {
		$code = $error->get_error_code();
		$data = $error->get_error_data();
		$status = 0;

		if ( is_array( $data ) && isset( $data['http_code'] ) ) {
			$status = absint( $data['http_code'] );
		}

		if ( in_array( $code, array( 'http_request_failed', 'http_failure' ), true ) ) {
			return new WP_Error(
				'api_unavailable',
				__( 'Unable to connect to WordPress.org.', 'plugin-downloader' )
			);
		}

		if ( 429 === $status ) {
			return new WP_Error(
				'api_rate_limited',
				__( 'WordPress.org is rate limiting requests. Please wait a moment and try again.', 'plugin-downloader' )
			);
		}

		if ( $status >= 500 ) {
			return new WP_Error(
				'api_unavailable',
				__( 'Unable to connect to WordPress.org.', 'plugin-downloader' )
			);
		}

		if ( $is_not_found || 'plugins_api_failed' === $code ) {
			$message = $error->get_error_message();
			if ( is_string( $message ) && false !== stripos( $message, 'Plugin not found' ) ) {
				return new WP_Error(
					'plugin_not_found',
					__( 'This plugin could not be found on WordPress.org.', 'plugin-downloader' )
				);
			}
		}

		return new WP_Error(
			'api_error',
			__( 'Unable to connect to WordPress.org.', 'plugin-downloader' )
		);
	}
}
