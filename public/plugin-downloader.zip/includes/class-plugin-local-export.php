<?php
/**
 * Export installed plugins as ZIP files.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Zips a local plugin directory and sends it to the browser.
 */
class Plugin_Downloader_Local_Export {

	/**
	 * Register the download handler.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_plugin_downloader_download_local', array( $this, 'handle_download' ) );
	}

	/**
	 * Build a nonce-protected download URL for an installed plugin.
	 *
	 * @param string $plugin_file Plugin basename.
	 * @return string
	 */
	public static function get_download_url( $plugin_file ) {
		$plugin_file = Plugin_Downloader_Security::sanitize_plugin_file( $plugin_file );
		if ( '' === $plugin_file ) {
			return '';
		}

		return wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'plugin_downloader_download_local',
					'plugin' => $plugin_file,
				),
				admin_url( 'admin-post.php' )
			),
			'plugin_downloader_download_local'
		);
	}

	/**
	 * Stream a ZIP of an installed plugin.
	 *
	 * @return void
	 */
	public function handle_download() {
		if ( ! Plugin_Downloader_Security::current_user_can_install() ) {
			wp_die(
				esc_html__( 'You do not have permission to download plugins.', 'plugin-downloader' ),
				esc_html__( 'Forbidden', 'plugin-downloader' ),
				array( 'response' => 403 )
			);
		}

		check_admin_referer( 'plugin_downloader_download_local' );

		$plugin_file = isset( $_GET['plugin'] ) ? Plugin_Downloader_Security::sanitize_plugin_file( wp_unslash( $_GET['plugin'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$zip = $this->create_zip( $plugin_file );
		if ( is_wp_error( $zip ) ) {
			Plugin_Downloader_Security::log( 'Local export failed: ' . $zip->get_error_code() );
			$this->redirect_with_error( $zip->get_error_message() );
		}

		$this->send_zip( $zip['path'], $zip['filename'] );
	}

	/**
	 * Create a ZIP of an installed plugin.
	 *
	 * @param string $plugin_file Plugin basename.
	 * @return array|WP_Error { path: string, filename: string }
	 */
	public function create_zip( $plugin_file ) {
		$plugin_file = Plugin_Downloader_Security::sanitize_plugin_file( $plugin_file );
		if ( '' === $plugin_file ) {
			return new WP_Error(
				'invalid_plugin',
				__( 'The plugin could not be found among the installed plugins.', 'plugin-downloader' )
			);
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();
		if ( ! isset( $plugins[ $plugin_file ] ) ) {
			return new WP_Error(
				'invalid_plugin',
				__( 'The plugin could not be found among the installed plugins.', 'plugin-downloader' )
			);
		}

		$source = $this->resolve_source_path( $plugin_file );
		if ( is_wp_error( $source ) ) {
			return $source;
		}

		$version  = isset( $plugins[ $plugin_file ]['Version'] ) ? $plugins[ $plugin_file ]['Version'] : '';
		$filename = $this->build_filename( $plugin_file, $version );

		$tmp = wp_tempnam( 'plugin-downloader-export' );
		if ( ! $tmp ) {
			return new WP_Error(
				'temp_file',
				__( 'The plugin ZIP could not be created.', 'plugin-downloader' )
			);
		}

		$zip_path = $tmp . '.zip';
		if ( file_exists( $tmp ) ) {
			wp_delete_file( $tmp );
		}

		$created = $this->zip_path( $source['root'], $source['path'], $zip_path );
		if ( is_wp_error( $created ) ) {
			if ( file_exists( $zip_path ) ) {
				wp_delete_file( $zip_path );
			}
			return $created;
		}

		if ( ! is_readable( $zip_path ) || 0 === (int) filesize( $zip_path ) ) {
			wp_delete_file( $zip_path );
			return new WP_Error(
				'empty_zip',
				__( 'The plugin ZIP could not be created.', 'plugin-downloader' )
			);
		}

		return array(
			'path'     => $zip_path,
			'filename' => $filename,
		);
	}

	/**
	 * Resolve and lock the plugin path inside WP_PLUGIN_DIR.
	 *
	 * @param string $plugin_file Plugin basename.
	 * @return array|WP_Error { root: string, path: string }
	 */
	private function resolve_source_path( $plugin_file ) {
		$plugin_root = wp_normalize_path( WP_PLUGIN_DIR );
		$dir         = dirname( $plugin_file );

		if ( '.' === $dir ) {
			$source = $plugin_root . '/' . $plugin_file;
		} else {
			$source = $plugin_root . '/' . $dir;
		}

		$real_root   = realpath( $plugin_root );
		$real_source = realpath( $source );

		if ( false === $real_root || false === $real_source ) {
			return new WP_Error(
				'invalid_plugin',
				__( 'The plugin could not be found among the installed plugins.', 'plugin-downloader' )
			);
		}

		$real_root   = wp_normalize_path( $real_root );
		$real_source = wp_normalize_path( $real_source );

		if ( $real_source !== $real_root && 0 !== strpos( $real_source, $real_root . '/' ) ) {
			return new WP_Error(
				'invalid_plugin',
				__( 'The plugin could not be found among the installed plugins.', 'plugin-downloader' )
			);
		}

		return array(
			'root' => $real_root,
			'path' => $real_source,
		);
	}

	/**
	 * ZIP a file or directory using ZipArchive, with PclZip as fallback.
	 *
	 * @param string $root     Normalized plugins directory.
	 * @param string $source   File or folder to zip.
	 * @param string $zip_path Destination zip path.
	 * @return true|WP_Error
	 */
	private function zip_path( $root, $source, $zip_path ) {
		if ( class_exists( 'ZipArchive' ) ) {
			$zip    = new ZipArchive();
			$opened = $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE );
			if ( true !== $opened ) {
				return new WP_Error(
					'zip_open',
					__( 'The plugin ZIP could not be created.', 'plugin-downloader' )
				);
			}

			$files = $this->collect_files( $root, $source );
			if ( empty( $files ) ) {
				$zip->close();
				return new WP_Error(
					'empty_plugin',
					__( 'The plugin ZIP could not be created.', 'plugin-downloader' )
				);
			}

			foreach ( $files as $absolute => $relative ) {
				$zip->addFile( $absolute, $relative );
			}

			$zip->close();
			return true;
		}

		if ( ! class_exists( 'PclZip' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		}

		$archive = new PclZip( $zip_path );
		$result  = $archive->create( $source, PCLZIP_OPT_REMOVE_PATH, $root );

		if ( 0 === $result ) {
			return new WP_Error(
				'zip_open',
				__( 'The plugin ZIP could not be created.', 'plugin-downloader' )
			);
		}

		return true;
	}

	/**
	 * Collect files to include in the ZIP.
	 *
	 * @param string $root   Plugins directory.
	 * @param string $source File or directory.
	 * @return array Map of absolute path => relative zip path.
	 */
	private function collect_files( $root, $source ) {
		$skip = array( '.git', '.svn', 'node_modules' );
		$list = array();

		if ( is_file( $source ) ) {
			$relative = ltrim( substr( $source, strlen( $root ) ), '/' );
			if ( '' !== $relative ) {
				$list[ $source ] = $relative;
			}
			return $list;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $source, FilesystemIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$absolute = wp_normalize_path( $file->getPathname() );
			$real     = realpath( $absolute );
			if ( false === $real ) {
				continue;
			}

			$real = wp_normalize_path( $real );
			if ( 0 !== strpos( $real, $root . '/' ) ) {
				continue;
			}

			$relative = ltrim( substr( $real, strlen( $root ) ), '/' );
			$parts    = explode( '/', $relative );
			$blocked  = false;
			foreach ( $parts as $part ) {
				if ( in_array( $part, $skip, true ) ) {
					$blocked = true;
					break;
				}
			}

			if ( $blocked || '' === $relative ) {
				continue;
			}

			$list[ $real ] = $relative;
		}

		return $list;
	}

	/**
	 * Build a safe download filename.
	 *
	 * @param string $plugin_file Plugin basename.
	 * @param string $version     Plugin version.
	 * @return string
	 */
	private function build_filename( $plugin_file, $version ) {
		$dir = dirname( $plugin_file );
		$slug = ( '.' === $dir ) ? basename( $plugin_file, '.php' ) : $dir;
		$slug = sanitize_file_name( $slug );

		$version = sanitize_file_name( (string) $version );
		if ( '' !== $version ) {
			return $slug . '-' . $version . '.zip';
		}

		return $slug . '.zip';
	}

	/**
	 * Send the ZIP and delete the temp file.
	 *
	 * @param string $path     Absolute zip path.
	 * @param string $filename Download name.
	 * @return void
	 */
	private function send_zip( $path, $filename ) {
		$filename = sanitize_file_name( $filename );
		if ( '' === $filename ) {
			$filename = 'plugin.zip';
		}

		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . (string) filesize( $path ) );
		header( 'X-Content-Type-Options: nosniff' );

		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		wp_delete_file( $path );
		exit;
	}

	/**
	 * Return to the local plugins screen with an error notice.
	 *
	 * @param string $message Error message.
	 * @return void
	 */
	private function redirect_with_error( $message ) {
		$referer    = wp_get_referer();
		$is_network = is_network_admin() || ( $referer && false !== strpos( $referer, '/wp-admin/network/' ) );

		$url = add_query_arg(
			array(
				'page'      => Plugin_Downloader_Admin::PAGE_LOCAL,
				'pd_export' => rawurlencode( $message ),
			),
			$is_network ? network_admin_url( 'admin.php' ) : admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
