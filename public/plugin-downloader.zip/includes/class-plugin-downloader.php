<?php
/**
 * Plugin bootstrap.
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads plugin components and registers hooks.
 */
class Plugin_Downloader {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin_Downloader|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return Plugin_Downloader
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->load_dependencies();
		$this->init_hooks();
	}

	/**
	 * Load required class files.
	 *
	 * @return void
	 */
	private function load_dependencies() {
		require_once PD_PLUGIN_DIR . 'includes/class-plugin-security.php';
		require_once PD_PLUGIN_DIR . 'includes/class-plugin-settings.php';
		require_once PD_PLUGIN_DIR . 'includes/class-plugin-api.php';
		require_once PD_PLUGIN_DIR . 'includes/class-plugin-installer.php';
		require_once PD_PLUGIN_DIR . 'includes/class-plugin-ajax.php';
		require_once PD_PLUGIN_DIR . 'includes/class-plugin-local-export.php';
		require_once PD_PLUGIN_DIR . 'admin/class-plugin-downloader-admin.php';
	}

	/**
	 * Register WordPress hooks.
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_action( 'init', array( $this, 'load_textdomain' ) );

		$settings = new Plugin_Downloader_Settings();
		add_action( 'admin_init', array( $settings, 'register' ) );

		$ajax = new Plugin_Downloader_Ajax();
		$ajax->register();

		$export = new Plugin_Downloader_Local_Export();
		$export->register();

		if ( is_admin() ) {
			$admin = new Plugin_Downloader_Admin();
			$admin->register();
		}
	}

	/**
	 * Load translations.
	 *
	 * @return void
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'plugin-downloader',
			false,
			dirname( PD_PLUGIN_BASENAME ) . '/languages'
		);
	}

	/**
	 * Activation: store defaults if missing. No remote requests.
	 *
	 * @return void
	 */
	public static function activate() {
		require_once PD_PLUGIN_DIR . 'includes/class-plugin-settings.php';

		if ( version_compare( PHP_VERSION, PD_MIN_PHP, '<' ) ) {
			deactivate_plugins( PD_PLUGIN_BASENAME );
			wp_die(
				esc_html(
					sprintf(
						/* translators: %s: required PHP version */
						__( 'Plugin Downloader requires PHP %s or higher.', 'plugin-downloader' ),
						PD_MIN_PHP
					)
				),
				esc_html__( 'Plugin activation failed', 'plugin-downloader' ),
				array( 'back_link' => true )
			);
		}

		global $wp_version;
		if ( version_compare( $wp_version, PD_MIN_WP, '<' ) ) {
			deactivate_plugins( PD_PLUGIN_BASENAME );
			wp_die(
				esc_html(
					sprintf(
						/* translators: %s: required WordPress version */
						__( 'Plugin Downloader requires WordPress %s or higher.', 'plugin-downloader' ),
						PD_MIN_WP
					)
				),
				esc_html__( 'Plugin activation failed', 'plugin-downloader' ),
				array( 'back_link' => true )
			);
		}

		if ( false === get_option( Plugin_Downloader_Settings::OPTION, false ) ) {
			add_option( Plugin_Downloader_Settings::OPTION, Plugin_Downloader_Settings::defaults() );
		}
	}

	/**
	 * Deactivation. Settings are kept until uninstall.
	 *
	 * @return void
	 */
	public static function deactivate() {
		// Intentionally empty. Options and transients are removed in uninstall.php only.
	}
}
