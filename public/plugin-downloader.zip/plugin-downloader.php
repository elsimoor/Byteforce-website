<?php
/**
 * Plugin Name:       Plugin Downloader
 * Plugin URI:        https://wordpress.org/plugins/plugin-downloader/
 * Description:       Search, download, install, and activate plugins from the official WordPress.org Plugin Directory without leaving wp-admin.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            BYTE FORCE
 * Author URI:        https://wordpress.org/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       plugin-downloader
 * Domain Path:       /languages
 * Network:           false
 *
 * @package Plugin_Downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PD_VERSION', '1.0.0' );
define( 'PD_PLUGIN_FILE', __FILE__ );
define( 'PD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PD_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'PD_MIN_WP', '6.0' );
define( 'PD_MIN_PHP', '7.4' );

require_once PD_PLUGIN_DIR . 'includes/class-plugin-downloader.php';

register_activation_hook( PD_PLUGIN_FILE, array( 'Plugin_Downloader', 'activate' ) );
register_deactivation_hook( PD_PLUGIN_FILE, array( 'Plugin_Downloader', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'Plugin_Downloader', 'instance' ) );
