=== Plugin Downloader ===
Contributors: byteforce
Tags: plugins, install, download, wordpress.org, admin
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Search, download, install, and activate plugins from the official WordPress.org Plugin Directory without leaving wp-admin.

== Description ==

Plugin Downloader is a WordPress administration plugin that lets users with the `install_plugins` capability search the official WordPress.org Plugin Directory, review plugin details, download official ZIP packages, and install or activate plugins using WordPress's own installer APIs.

It is designed to feel like a native wp-admin screen: familiar buttons, spacing, and notices. It does not scrape HTML. All remote data comes from the official WordPress.org Plugin API.

= Features =

* Search the WordPress.org Plugin Directory by keyword
* Browse paginated results inside wp-admin
* View icon, author, version, active installs, rating, last updated, and compatibility
* Download the official plugin ZIP from WordPress.org
* Download a ZIP of any plugin already installed on the site
* Install plugins with `Plugin_Upgrader`
* Activate plugins with `activate_plugin()`
* Detect already installed, inactive, and active plugins
* Short-lived API caching
* Settings for results per page, cache duration, and automatic activation
* Multisite-aware: never network-activates plugins automatically

= Security notes =

* Every AJAX request checks a nonce and the `install_plugins` capability
* Activation also requires `activate_plugins`
* Plugin slugs are validated against a strict pattern
* Plugins are verified through the WordPress.org API before download or install
* ZIP URLs are only accepted from official WordPress.org download hosts
* Users cannot submit an arbitrary URL for the server to fetch
* Remote HTML is never printed; names and descriptions are stripped and escaped
* Debug logging runs only when `WP_DEBUG` is enabled and does not record secrets

== Installation ==

1. Download or zip the `plugin-downloader` folder.
2. In WordPress, go to Plugins → Add New → Upload Plugin.
3. Upload `plugin-downloader.zip` and click Install Now.
4. Activate Plugin Downloader.
5. Open **Plugin Downloader** in the admin menu.

== Usage ==

1. Go to **Plugin Downloader → Search Plugins**.
2. Type a keyword such as `Elementor` and press Enter or click Search.
3. Review the plugin card.
4. Choose **Download** for the official ZIP, **Install** to install, or **Install & Activate** to install and activate.
5. If a plugin is already installed but inactive, use **Activate**.
6. Go to **Plugin Downloader → Local Plugins** to download a ZIP of any installed plugin.
7. Adjust **Plugin Downloader → Settings** as needed.

== Frequently Asked Questions ==

= Does this replace Plugins → Add New? =

No. It is an alternative search and install screen that uses the same WordPress.org API and the same WordPress installer.

= Can I download a plugin that is already installed? =

Yes. Open **Plugin Downloader → Local Plugins** and click **Download ZIP**. Only plugins listed by WordPress in `wp-content/plugins` can be exported. Arbitrary paths are rejected.

= Can I download a ZIP without installing? =

Yes. Download asks WordPress.org for the official package URL, verifies the host, and lets your browser download that ZIP.

= Does it work on WordPress Multisite? =

Yes. Super administrators can search and install from Network Admin or a site dashboard. The plugin will not network-activate anything. Activate plugins from each site's Plugins screen.

= Why was installation blocked? =

WordPress may have `DISALLOW_FILE_MODS` enabled, the plugins directory may not be writable, or your account may lack `install_plugins`. The plugin reports these cases instead of failing silently.

= Does uninstall remove plugins I installed with it? =

No. Uninstall only deletes Plugin Downloader settings and its transients.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
Initial release of Plugin Downloader.
