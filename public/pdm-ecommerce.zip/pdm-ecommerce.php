<?php
/**
 * Plugin Name: PDM – Ecommerce
 * Description: A secure API extension for WooCommerce with Public/Secret key authentication.
 * Version: 1.0.0
 * Author: Walid moultamiss
 * Text Domain: pdm-ecommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define constants
define( 'PDM_ECOMMERCE_VERSION', '1.0.0' );
define( 'PDM_ECOMMERCE_PATH', plugin_dir_path( __FILE__ ) );
define( 'PDM_ECOMMERCE_URL', plugin_dir_url( __FILE__ ) );

// Include required files
require_once PDM_ECOMMERCE_PATH . 'includes/class-pdm-auth.php';
require_once PDM_ECOMMERCE_PATH . 'includes/class-pdm-api.php';
require_once PDM_ECOMMERCE_PATH . 'includes/class-pdm-webhooks.php';
require_once PDM_ECOMMERCE_PATH . 'includes/class-pdm-cors.php';

/**
 * Main PDM Ecommerce Class
 */
class PDM_Ecommerce {

	/**
	 * Instance of this class.
	 * @var object
	 */
	protected static $instance = null;

	/**
	 * Return an instance of this class.
	 * @return object
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
		
		// Register activation hook
		register_activation_hook( __FILE__, array( $this, 'activate' ) );

		// Handle Session Transfer
		add_action( 'template_redirect', array( $this, 'handle_session_transfer' ) );
	}

	/**
	 * Initialize the plugin
	 */
	public function init() {
		// Initialize CORS
		PDM_CORS::get_instance();

		// Initialize Auth
		PDM_Auth::get_instance();
		
		// Initialize API
		PDM_API::get_instance();

		// Initialize Webhooks
		PDM_Webhooks::get_instance();

		if ( is_admin() ) {
			add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		}
	}

	/**
	 * Activation Hook
	 */
	public function activate() {
		// Ensure keys exist
		PDM_Auth::generate_keys();
	}

	/**
	 * Handle Session Transfer Redirection
	 */
	public function handle_session_transfer() {
		if ( isset( $_GET['pdm_transfer_token'] ) ) {
			$token = sanitize_text_field( $_GET['pdm_transfer_token'] );
			$stored_token = get_transient( 'pdm_session_' . $token );

			if ( $stored_token && isset( $stored_token['cart_data'] ) ) {
				// Clear current cart
				WC()->cart->empty_cart();

				// Restore cart items from the API session
				foreach ( $stored_token['cart_data'] as $item ) {
					$product_id   = $item['product_id'];
					$quantity     = $item['quantity'];
					$variation_id = isset( $item['variation_id'] ) ? $item['variation_id'] : 0;
					$variation    = isset( $item['variation'] ) ? $item['variation'] : array();

					WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );
				}

				// Optional: Log in the user if user_id is provided
				if ( ! empty( $stored_token['user_id'] ) ) {
					wp_set_auth_cookie( $stored_token['user_id'] );
				}

				// Delete transient after use
				delete_transient( 'pdm_session_' . $token );

				// Redirect to checkout
				wp_safe_redirect( wc_get_checkout_url() );
				exit;
			} else {
				wp_die( __( 'Invalid or expired session transfer token.', 'pdm-ecommerce' ) );
			}
		}
	}

	/**
	 * Add Admin Menu
	 */
	public function add_admin_menu() {
		add_menu_page(
			__( 'PDM Ecommerce', 'pdm-ecommerce' ),
			__( 'PDM Ecommerce', 'pdm-ecommerce' ),
			'manage_options',
			'pdm-ecommerce',
			array( $this, 'admin_page' ),
			'dashicons-cart',
			56
		);
	}

	/**
	 * Admin Page Content
	 */
	public function admin_page() {
		$public_key = get_option( 'pdm_public_key' );
		$secret_key = get_option( 'pdm_secret_key' );
		$webhook_url = get_option( 'pdm_webhook_url' );
		$cors_origin = get_option( 'pdm_cors_origin', '*' );

		if ( isset( $_POST['save_settings'] ) && check_admin_referer( 'pdm_save_settings_action', 'pdm_nonce' ) ) {
			if ( isset( $_POST['webhook_url'] ) ) {
				update_option( 'pdm_webhook_url', esc_url_raw( $_POST['webhook_url'] ) );
				$webhook_url = get_option( 'pdm_webhook_url' );
			}
			if ( isset( $_POST['cors_origin'] ) ) {
				update_option( 'pdm_cors_origin', sanitize_text_field( $_POST['cors_origin'] ) );
				$cors_origin = get_option( 'pdm_cors_origin' );
			}
			echo '<div class="updated"><p>' . esc_html__( 'Settings saved.', 'pdm-ecommerce' ) . '</p></div>';
		}

		if ( isset( $_POST['generate_keys'] ) && check_admin_referer( 'pdm_save_settings_action', 'pdm_nonce' ) ) {
			PDM_Auth::generate_keys( true );
			$public_key = get_option( 'pdm_public_key' );
			$secret_key = get_option( 'pdm_secret_key' );
			echo '<div class="updated"><p>' . esc_html__( 'Keys regenerated successfully.', 'pdm-ecommerce' ) . '</p></div>';
		}

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'PDM Ecommerce – API Settings', 'pdm-ecommerce' ); ?></h1>
			<form method="post">
				<?php wp_nonce_field( 'pdm_save_settings_action', 'pdm_nonce' ); ?>
				
				<div class="card" style="max-width: 600px;">
					<h2><?php esc_html_e( 'API Keys', 'pdm-ecommerce' ); ?></h2>
					<p><strong><?php esc_html_e( 'Use these keys to authenticate your peer-to-peer requests.', 'pdm-ecommerce' ); ?></strong></p>
					<table class="form-table">
						<tr>
							<th scope="row"><label><?php esc_html_e( 'Public Key', 'pdm-ecommerce' ); ?></label></th>
							<td><code><?php echo esc_html( $public_key ); ?></code></td>
						</tr>
						<tr>
							<th scope="row"><label><?php esc_html_e( 'Secret Key', 'pdm-ecommerce' ); ?></label></th>
							<td><code><?php echo esc_html( $secret_key ); ?></code></td>
						</tr>
					</table>
					<input type="submit" name="generate_keys" class="button button-secondary" value="<?php esc_attr_e( 'Regenerate Keys', 'pdm-ecommerce' ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to regenerate keys? Old keys will stop working.', 'pdm-ecommerce' ); ?>');">
				</div>

				<div class="card" style="max-width: 600px; margin-top: 20px;">
					<h2><?php esc_html_e( 'Webhooks', 'pdm-ecommerce' ); ?></h2>
					<p><?php esc_html_e( 'The plugin will send a POST request with order details to this URL when a purchase is completed.', 'pdm-ecommerce' ); ?></p>
					<table class="form-table">
						<tr>
							<th scope="row"><label for="webhook_url"><?php esc_html_e( 'External Webhook URL', 'pdm-ecommerce' ); ?></label></th>
							<td>
								<input type="url" name="webhook_url" id="webhook_url" value="<?php echo esc_attr( $webhook_url ); ?>" class="regular-text" placeholder="https://other-site.com/webhook-receiver">
							</td>
						</tr>
					</table>
				</div>

				<div class="card" style="max-width: 600px; margin-top: 20px;">
					<h2><?php esc_html_e( 'CORS Settings', 'pdm-ecommerce' ); ?></h2>
					<p><?php esc_html_e( 'Configure Cross-Origin Resource Sharing to allow your frontend to access the API directly.', 'pdm-ecommerce' ); ?></p>
					<table class="form-table">
						<tr>
							<th scope="row"><label for="cors_origin"><?php esc_html_e( 'Allowed Origin', 'pdm-ecommerce' ); ?></label></th>
							<td>
								<input type="text" name="cors_origin" id="cors_origin" value="<?php echo esc_attr( $cors_origin ); ?>" class="regular-text" placeholder="* or https://your-frontend.com">
								<p class="description"><?php esc_html_e( 'Use * to allow all origins, or specify your frontend domain (e.g., https://your-frontend.com)', 'pdm-ecommerce' ); ?></p>
							</td>
						</tr>
					</table>
					<input type="submit" name="save_settings" class="button button-primary" value="<?php esc_attr_e( 'Save Settings', 'pdm-ecommerce' ); ?>">
				</div>
			</form>
			
			<div class="card" style="max-width: 600px; margin-top: 20px;">
				<h2><?php esc_html_e( 'API Documentation', 'pdm-ecommerce' ); ?></h2>
				<p><?php esc_html_e( 'Endpoints are prefixed with:', 'pdm-ecommerce' ); ?> <code>/wp-json/pdm-ecommerce/v1</code></p>
				<ul>
					<li><strong>GET /categories</strong> - <?php esc_html_e( 'List all categories with subcategories.', 'pdm-ecommerce' ); ?></li>
					<li><strong>GET /products</strong> - <?php esc_html_e( 'List products (search & pagination available).', 'pdm-ecommerce' ); ?></li>
					<li><strong>GET /cart</strong> - <?php esc_html_e( 'View cart content.', 'pdm-ecommerce' ); ?></li>
					<li><strong>POST /cart/add</strong> - <?php esc_html_e( 'Add product to cart.', 'pdm-ecommerce' ); ?></li>
					<li><strong>GET /cart/session</strong> - <?php esc_html_e( 'Get magic link for checkout.', 'pdm-ecommerce' ); ?></li>
				</ul>
				<p><em><?php esc_html_e( 'All requests must include X-PDM-Public-Key and X-PDM-Secret-Key headers.', 'pdm-ecommerce' ); ?></em></p>
			</div>
		</div>
		<?php
	}
}

// Start the plugin
PDM_Ecommerce::get_instance();
