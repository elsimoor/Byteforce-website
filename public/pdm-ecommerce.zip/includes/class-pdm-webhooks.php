<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PDM Webhooks Class
 */
class PDM_Webhooks {

	protected static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		// Trigger webhook when order is marked as "done" (Completed)
		add_action( 'woocommerce_order_status_completed', array( $this, 'trigger_order_webhook' ) );
		
		// Optional: also trigger on payment complete if it directly completes the order
		add_action( 'woocommerce_payment_complete', array( $this, 'trigger_order_webhook' ) );
	}

	/**
	 * Send order details to the external webhook
	 *
	 * @param int $order_id
	 */
	public function trigger_order_webhook( $order_id ) {
		// Prevent multiple webhooks for the same order in the same request
		static $processed_orders = array();
		if ( in_array( $order_id, $processed_orders ) ) {
			return;
		}

		$webhook_url = get_option( 'pdm_webhook_url' );

		if ( ! $webhook_url ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		// Prepare data
		$data = array(
			'event'      => 'order.completed',
			'done'       => true, // Explicitly mark as "done" as per user request
			'order_id'   => $order->get_id(),
			'number'     => $order->get_order_number(),
			'status'     => $order->get_status(),
			'total'      => $order->get_total(),
			'currency'   => $order->get_currency(),
			'items'      => array(),
			'customer'   => array(
				'id'         => $order->get_customer_id(),
				'email'      => $order->get_billing_email(),
				'first_name' => $order->get_billing_first_name(),
				'last_name'  => $order->get_billing_last_name(),
			),
			'domain'     => str_replace( array( 'http://', 'https://' ), '', home_url() ),
		);

		foreach ( $order->get_items() as $item_id => $item ) {
			$product = $item->get_product();
			$data['items'][] = array(
				'product_id' => $item->get_product_id(),
				'name'       => $item->get_name(),
				'quantity'   => $item->get_quantity(),
				'subtotal'   => $item->get_subtotal(),
				'total'      => $item->get_total(),
			);
		}

		// Send POST request
		wp_remote_post( $webhook_url, array(
			'method'      => 'POST',
			'timeout'     => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking'    => false, // Don't block order processing
			'headers'     => array(
				'Content-Type' => 'application/json',
			),
			'body'        => wp_json_encode( $data ),
			'cookies'     => array(),
		) );
	}
}
