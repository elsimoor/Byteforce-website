<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PDM Auth Class
 */
class PDM_Auth {

	/**
	 * Instance of this class.
	 */
	protected static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Generate Public and Secret Keys
	 */
	public static function generate_keys( $force = false ) {
		$public = get_option( 'pdm_public_key' );
		$secret = get_option( 'pdm_secret_key' );

		if ( ! $public || ! $secret || $force ) {
			$public = 'pdm_pub_' . bin2hex( random_bytes( 16 ) );
			$secret = 'pdm_sec_' . bin2hex( random_bytes( 32 ) );

			update_option( 'pdm_public_key', $public );
			update_option( 'pdm_secret_key', $secret );
		}
	}

	/**
	 * Validate Request
	 *
	 * @param WP_REST_Request $request
	 * @return bool|WP_Error
	 */
	public static function validate_request( $request ) {
		$public_key_header = $request->get_header( 'X-PDM-Public-Key' );
		$secret_key_header = $request->get_header( 'X-PDM-Secret-Key' );

		$stored_public = get_option( 'pdm_public_key' );
		$stored_secret = get_option( 'pdm_secret_key' );

		if ( ! $public_key_header || ! $secret_key_header ) {
			return new WP_Error( 'pdm_missing_auth', __( 'Authentication headers are missing.', 'pdm-ecommerce' ), array( 'status' => 401 ) );
		}

		if ( $public_key_header !== $stored_public || $secret_key_header !== $stored_secret ) {
			return new WP_Error( 'pdm_invalid_auth', __( 'Invalid Public or Secret Key.', 'pdm-ecommerce' ), array( 'status' => 403 ) );
		}

		return true;
	}
}
