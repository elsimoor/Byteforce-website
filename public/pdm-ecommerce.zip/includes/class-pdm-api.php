<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PDM API Class
 */
class PDM_API {

	protected static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register API routes
	 */
	public function register_routes() {
		register_rest_route( 'pdm-ecommerce/v1', '/categories', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_categories' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/products', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_products' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/search', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_products' ), // Reuse get_products for search
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/cart', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_cart' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/cart/add', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'add_to_cart' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
			'args'                => array(
				'product_id' => array( 'required' => true, 'type' => 'integer' ),
				'quantity'   => array( 'default' => 1, 'type' => 'integer' ),
			),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/cart/update', array(
			'methods'             => 'POST',
			'callback'            => array( $this, 'update_cart_item' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
			'args'                => array(
				'product_id' => array( 'required' => true, 'type' => 'integer' ),
				'quantity'   => array( 'required' => true, 'type' => 'integer' ),
			),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/cart/remove', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'remove_from_cart' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
			'args'                => array(
				'product_id' => array( 'required' => true, 'type' => 'integer' ),
			),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/cart/clear', array(
			'methods'             => 'DELETE',
			'callback'            => array( $this, 'clear_cart' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
		) );

		register_rest_route( 'pdm-ecommerce/v1', '/cart/session', array(
			'methods'             => 'GET',
			'callback'            => array( $this, 'get_session_link' ),
			'permission_callback' => array( 'PDM_Auth', 'validate_request' ),
		) );
	}

	/**
	 * Add to Cart (Remote)
	 */
	public function add_to_cart( $request ) {
		$product_id   = (int) $request->get_param( 'product_id' );
		$variation_id = (int) $request->get_param( 'variation_id' );
		$quantity     = (int) $request->get_param( 'quantity' );
		$variation    = $request->get_param( 'variation' );

		// Validate product exists
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new WP_Error( 'invalid_product', 'Product not found.', array( 'status' => 404 ) );
		}

		$external_session_id = $request->get_header( 'X-PDM-Session-ID' );
		if ( ! $external_session_id ) {
			$external_session_id = 'default_remote';
		}

		$cart_data = get_transient( 'pdm_remote_cart_' . $external_session_id );
		if ( ! is_array( $cart_data ) ) {
			$cart_data = array();
		}

		// Calculate a unique key for the item based on product_id and variation attributes
		$item_key = $product_id . '_' . $variation_id . '_' . md5( json_encode( $variation ) );

		$found = false;
		foreach ( $cart_data as &$item ) {
			$existing_key = $item['product_id'] . '_' . ( isset( $item['variation_id'] ) ? $item['variation_id'] : 0 ) . '_' . md5( json_encode( isset( $item['variation'] ) ? $item['variation'] : array() ) );
			
			if ( $existing_key === $item_key ) {
				$item['quantity'] += $quantity;
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			$cart_data[] = array(
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'variation'    => $variation,
				'quantity'     => $quantity,
			);
		}

		set_transient( 'pdm_remote_cart_' . $external_session_id, $cart_data, 24 * HOUR_IN_SECONDS );

		return rest_ensure_response( array(
			'success' => true,
			'cart'    => $cart_data,
		) );
	}

	/**
	 * Update Cart Item Quantity
	 */
	public function update_cart_item( $request ) {
		$product_id = (int) $request->get_param( 'product_id' );
		$quantity   = (int) $request->get_param( 'quantity' );

		if ( $quantity < 0 ) {
			return new WP_Error( 'invalid_quantity', 'Quantity must be positive.', array( 'status' => 400 ) );
		}

		$external_session_id = $request->get_header( 'X-PDM-Session-ID' );
		if ( ! $external_session_id ) {
			$external_session_id = 'default_remote';
		}

		$cart_data = get_transient( 'pdm_remote_cart_' . $external_session_id );
		if ( ! is_array( $cart_data ) ) {
			return new WP_Error( 'cart_empty', 'Cart is empty.', array( 'status' => 404 ) );
		}

		$found = false;
		foreach ( $cart_data as $key => &$item ) {
			if ( $item['product_id'] === $product_id ) {
				if ( $quantity === 0 ) {
					unset( $cart_data[$key] );
				} else {
					$item['quantity'] = $quantity;
				}
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return new WP_Error( 'item_not_found', 'Item not found in cart.', array( 'status' => 404 ) );
		}

		$cart_data = array_values( $cart_data );
		set_transient( 'pdm_remote_cart_' . $external_session_id, $cart_data, 24 * HOUR_IN_SECONDS );

		return rest_ensure_response( array(
			'success' => true,
			'cart'    => $cart_data,
		) );
	}

	/**
	 * Remove Item from Cart
	 */
	public function remove_from_cart( $request ) {
		$product_id = (int) $request->get_param( 'product_id' );

		$external_session_id = $request->get_header( 'X-PDM-Session-ID' );
		if ( ! $external_session_id ) {
			$external_session_id = 'default_remote';
		}

		$cart_data = get_transient( 'pdm_remote_cart_' . $external_session_id );
		if ( ! is_array( $cart_data ) ) {
			return new WP_Error( 'cart_empty', 'Cart is empty.', array( 'status' => 404 ) );
		}

		$found = false;
		foreach ( $cart_data as $key => $item ) {
			if ( $item['product_id'] === $product_id ) {
				unset( $cart_data[$key] );
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return new WP_Error( 'item_not_found', 'Item not found in cart.', array( 'status' => 404 ) );
		}

		$cart_data = array_values( $cart_data );
		set_transient( 'pdm_remote_cart_' . $external_session_id, $cart_data, 24 * HOUR_IN_SECONDS );

		return rest_ensure_response( array(
			'success' => true,
			'cart'    => $cart_data,
		) );
	}

	/**
	 * Clear Cart
	 */
	public function clear_cart( $request ) {
		$external_session_id = $request->get_header( 'X-PDM-Session-ID' );
		if ( ! $external_session_id ) {
			$external_session_id = 'default_remote';
		}

		delete_transient( 'pdm_remote_cart_' . $external_session_id );

		return rest_ensure_response( array(
			'success' => true,
			'message' => 'Cart cleared successfully.',
		) );
	}

	/**
	 * Get Session Transfer Link
	 */
	public function get_session_link( $request ) {
		$external_session_id = $request->get_header( 'X-PDM-Session-ID' );
		if ( ! $external_session_id ) {
			return new WP_Error( 'missing_session', 'X-PDM-Session-ID header is required.', array( 'status' => 400 ) );
		}

		$cart_data = get_transient( 'pdm_remote_cart_' . $external_session_id );
		if ( ! $cart_data ) {
			return new WP_Error( 'empty_cart', 'No cart data found for this session.', array( 'status' => 404 ) );
		}

		$token = bin2hex( random_bytes( 16 ) );
		$transfer_data = array(
			'cart_data' => $cart_data,
			'user_id'   => get_current_user_id(), // If the API auth is tied to a user
		);

		set_transient( 'pdm_session_' . $token, $transfer_data, 10 * MINUTE_IN_SECONDS );

		$link = add_query_arg( 'pdm_transfer_token', $token, home_url() );

		return rest_ensure_response( array(
			'checkout_url' => $link,
		) );
	}

	/**
	 * Get Categories with subcategories
	 */
	public function get_categories( $request ) {
		$args = array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'parent'     => 0,
		);

		$categories = get_terms( $args );
		$response = array();

		foreach ( $categories as $category ) {
			$response[] = $this->format_category( $category );
		}

		return rest_ensure_response( $response );
	}

	/**
	 * Format Category with children
	 */
	private function format_category( $category ) {
		$children = get_terms( array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'parent'     => $category->term_id,
		) );

		$formatted_children = array();
		foreach ( $children as $child ) {
			$formatted_children[] = $this->format_category( $child );
		}

		return array(
			'id'          => $category->term_id,
			'name'        => $category->name,
			'slug'        => $category->slug,
			'description' => $category->description,
			'count'       => $category->count,
			'children'    => $formatted_children,
		);
	}

	/**
	 * Get Products with pagination and search
	 */
	public function get_products( $request ) {
		$search   = $request->get_param( 's' );
		$page     = $request->get_param( 'page' ) ? $request->get_param( 'page' ) : 1;
		$per_page = $request->get_param( 'per_page' ) ? $request->get_param( 'per_page' ) : 10;
		$category = $request->get_param( 'category' );

		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			's'              => $search,
		);

		if ( $category ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'slug',
					'terms'    => $category,
				),
			);
		}

		$query = new WP_Query( $args );
		$products = array();

		foreach ( $query->posts as $post ) {
			$product = wc_get_product( $post->ID );
			$products[] = $this->format_product( $product );
		}

		return rest_ensure_response( array(
			'products'     => $products,
			'total'        => $query->found_posts,
			'total_pages'  => $query->max_num_pages,
			'current_page' => (int) $page,
		) );
	}

	/**
	 * Format Product Data
	 */
	private function format_product( $product ) {
		$images = array();
		$attachment_ids = array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() );
		foreach ( $attachment_ids as $id ) {
			if ( $id ) {
				$images[] = wp_get_attachment_url( $id );
			}
		}

		$data = array(
			'id'            => $product->get_id(),
			'name'          => $product->get_name(),
			'slug'          => $product->get_slug(),
			'type'          => $product->get_type(),
			'price'         => $product->get_price(),
			'regular_price' => $product->get_regular_price(),
			'sale_price'    => $product->get_sale_price(),
			'description'   => $product->get_description(),
			'short_desc'    => $product->get_short_description(),
			'images'        => $images,
			'stock_status'  => $product->get_stock_status(),
			'categories'    => wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) ),
			'attributes'    => array(),
			'variations'    => array(),
		);

		// Get Attributes
		foreach ( $product->get_attributes() as $name => $attribute ) {
			$options = array();
			if ( $attribute->is_taxonomy() ) {
				$terms = $attribute->get_terms();
				foreach ( $terms as $term ) {
					$options[] = array(
						'name' => $term->name,
						'slug' => $term->slug,
					);
				}
			} else {
				foreach ( $attribute->get_options() as $option ) {
					$options[] = array(
						'name' => $option,
						'slug' => sanitize_title( $option ),
					);
				}
			}

			$data['attributes'][] = array(
				'name'      => wc_attribute_label( $name ),
				'slug'      => $name,
				'options'   => $options,
				'visible'   => $attribute->get_visible(),
				'variation' => $attribute->get_variation(),
			);
		}

		// Get Variations for variable products
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_visible_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				$data['variations'][] = array(
					'id'            => $variation->get_id(),
					'attributes'    => $variation->get_variation_attributes(),
					'price'         => $variation->get_price(),
					'regular_price' => $variation->get_regular_price(),
					'sale_price'    => $variation->get_sale_price(),
					'stock_status'  => $variation->get_stock_status(),
					'image'         => wp_get_attachment_url( $variation->get_image_id() ),
				);
			}
		}

		return $data;
	}

	/**
	 * Get Cart Content (Remote)
	 */
	public function get_cart( $request ) {
		// Get the external session ID
		$external_session_id = $request->get_header( 'X-PDM-Session-ID' );
		if ( ! $external_session_id ) {
			$external_session_id = 'default_remote';
		}

		// Retrieve cart data from transient
		$cart_data = get_transient( 'pdm_remote_cart_' . $external_session_id );
		if ( ! is_array( $cart_data ) ) {
			$cart_data = array();
		}

		// Format cart items with product details
		$items = array();
		$total = 0;
		$count = 0;

		foreach ( $cart_data as $item ) {
			$product_id   = $item['product_id'];
			$variation_id = isset( $item['variation_id'] ) ? $item['variation_id'] : 0;
			
			// Get the correct product object (variation or parent)
			$display_id = $variation_id > 0 ? $variation_id : $product_id;
			$product = wc_get_product( $display_id );

			if ( ! $product ) {
				continue;
			}

			$quantity = $item['quantity'];
			$price = (float) $product->get_price();
			$subtotal = $price * $quantity;

			$items[] = array(
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'name'         => $product->get_name(),
				'quantity'     => $quantity,
				'price'        => $price,
				'subtotal'     => $subtotal,
				'total'        => $subtotal,
				'image'        => wp_get_attachment_url( $product->get_image_id() ),
				'variation'    => isset( $item['variation'] ) ? $item['variation'] : array(),
			);

			$total += $subtotal;
			$count += $quantity;
		}

		return rest_ensure_response( array(
			'items' => $items,
			'total' => $total,
			'count' => $count,
		) );
	}
}
