<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PDM CORS Handler Class
 */
class PDM_CORS {

	protected static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'add_cors_headers' ) );
	}

	/**
	 * Add CORS headers to REST API responses
	 */
	public function add_cors_headers() {
		// Get allowed origin from settings, default to *
		$allowed_origin = get_option( 'pdm_cors_origin', '*' );

		header( 'Access-Control-Allow-Origin: ' . $allowed_origin );
		header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS' );
		header( 'Access-Control-Allow-Headers: Content-Type, X-PDM-Public-Key, X-PDM-Secret-Key, X-PDM-Session-ID, Authorization' );
		header( 'Access-Control-Allow-Credentials: true' );
		header( 'Access-Control-Max-Age: 86400' ); // Cache preflight for 24 hours

		// Handle preflight OPTIONS requests
		if ( $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {
			status_header( 200 );
			exit;
		}
	}
}
