# PDM Ecommerce – API Documentation

This plugin provides a secure API to access WooCommerce data from external platforms and synchronize carts.

## Base URL
`https://your-domain.com/wp-json/pdm-ecommerce/v1`

## Authentication
All requests MUST include the following headers:
- `X-PDM-Public-Key`: Your public API key.
- `X-PDM-Secret-Key`: Your secret API key.

Keys can be found in the WordPress Admin under **PDM Ecommerce**.

## CORS Configuration

The plugin includes built-in CORS support to allow your frontend applications to call the API directly without requiring a proxy.

**Configuration:**
1. Go to **PDM Ecommerce** in WordPress Admin
2. Find the **CORS Settings** section
3. Set the **Allowed Origin**:
   - Use `*` to allow all origins (for development/testing)
   - Use your specific domain for production (e.g., `https://your-frontend.com`)

**Headers Automatically Added:**
- `Access-Control-Allow-Origin`
- `Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS`
- `Access-Control-Allow-Headers: Content-Type, X-PDM-Public-Key, X-PDM-Secret-Key, X-PDM-Session-ID, Authorization`
- `Access-Control-Allow-Credentials: true`

The plugin automatically handles preflight OPTIONS requests.

---

## Endpoints

### 1. GET /categories
Retrieve a hierarchical list of product categories.

---

### 2. GET /products
Retrieve a list of products with pagination and search.

**Parameters:**
- `s` (optional): Search query.
- `page` (optional): Current page (default: 1).
- `per_page` (optional): Items per page (default: 10).
- `category` (optional): Filter by category slug.

---

### 2.1 GET /search
Dedicated search endpoint. Works the same as `/products` but specifically intended for search functionality.

**Parameters:**
- `s` (optional): Search query.
- `page` (optional): Current page.
- `per_page` (optional): Items per page.

---

**Product Data Structure (Expanded):**
All product-returning endpoints now include the following expanded structure:

```json
{
  "products": [
    {
      "id": 45,
      "name": "Variable Cool T-shirt",
      "slug": "variable-cool-t-shirt",
      "type": "variable",
      "price": "19.99",
      "regular_price": "25.00",
      "sale_price": "19.99",
      "description": "...",
      "short_desc": "...",
      "images": [
        "https://domain.com/wp-content/uploads/main.jpg",
        "https://domain.com/wp-content/uploads/gallery1.jpg"
      ],
      "stock_status": "instock",
      "categories": ["Clothing", "T-shirts"],
      "attributes": [
        {
          "name": "Color",
          "slug": "pa_color",
          "options": ["Red", "Blue"],
          "visible": true,
          "variation": true
        }
      ],
      "variations": [
        {
          "id": 46,
          "attributes": {
            "attribute_pa_color": "red"
          },
          "price": "19.99",
          "regular_price": "25.00",
          "sale_price": "19.99",
          "stock_status": "instock",
          "image": "https://domain.com/wp-content/uploads/red-t-shirt.jpg"
        }
      ]
    }
  ],
  "total": 50,
  "total_pages": 5,
  "current_page": 1
}
```

### 3. GET /cart
Retrieve the current cart contents (based on WordPress session).

---

### 4. POST /cart/add
Add a product to a "remote cart" tied to a session ID.

**Headers:**
- `X-PDM-Session-ID`: (Recommended) A unique ID from your external platform to track the user's cart.

**Parameters:**
- `product_id` (required): ID of the product.
- `quantity` (optional): Defaults to 1.

---

### 5. GET /cart/session
Generate a magic link to transfer the remote cart to the WordPress checkout.

**Headers:**
- `X-PDM-Session-ID`: Must match the ID used in `/cart/add`.

**Response:**
```json
{
  "checkout_url": "https://your-site.com/?pdm_transfer_token=abc123..."
}
```

---

## Webhooks

The plugin sends a POST request to your external **Webhook URL** (configured in Admin) when an order is completed.

**Payload Example:**
```json
{
  "event": "order.completed",
  "done": true,
  "order_id": 123,
  "number": "123",
  "status": "completed",
  "total": "45.00",
  "currency": "USD",
  "items": [
    {
      "product_id": 45,
      "name": "Cool T-shirt",
      "quantity": 1,
      "subtotal": "45.00",
      "total": "45.00"
    }
  ],
  "customer": {
    "id": 5,
    "email": "customer@example.com",
    "first_name": "John",
    "last_name": "Doe"
  }
}
```
