<?php 
if ( ! defined( 'ABSPATH' ) ) exit; 
$scanner = new PDM_Media_Scanner();
$db_size = $scanner->get_db_size();
?>

<div class="wrap pdm-om-wrap">
    <h1>PDM – Optimize Media</h1>

        <!-- Global Stats -->
        <div class="pdm-om-card pdm-om-global-stats">
            <h2>Statistiques globales</h2>
            <div class="pdm-om-stats-grid">
                <div class="pdm-om-stat-box">
                    <span class="pdm-om-stat-label">Total économisé</span>
                    <span class="pdm-om-stat-value" id="pdm-om-total-savings-site"><?php echo size_format( get_option( 'pdm_om_total_savings', 0 ) ); ?></span>
                </div>
                <div class="pdm-om-stat-box">
                    <span class="pdm-om-stat-label">Taille Base de Données</span>
                    <span class="pdm-om-stat-value"><?php echo size_format( $db_size ); ?></span>
                </div>
            </div>
        </div>

        <!-- Settings & Controls -->
        <div class="pdm-om-card pdm-om-controls">
            <h2>Paramètres d’optimisation</h2>
            <div class="pdm-om-setting">
                <label for="pdm-om-level">Niveau d'optimisation : <span id="pdm-om-level-value">50</span>%</label>
                <input type="range" id="pdm-om-level" name="pdm-om-level" min="10" max="90" value="50" step="10">
                <p class="description">10% = compression légère, 90% = compression agressive.</p>
                
                <div style="margin-top: 15px;">
                    <label>
                        <input type="checkbox" id="pdm-om-convert-webp" name="pdm-om-convert-webp">
                        Convertir en WebP
                    </label>
                    <div id="pdm-om-rename-wrap" style="margin-left: 20px; margin-top: 5px; display: none;">
                        <label>
                            <input type="checkbox" id="pdm-om-rename-webp" name="pdm-om-rename-webp">
                            Changer l'extension en .webp (Modifie les URLs et la base de données)
                        </label>
                    </div>
                </div>

                <div style="margin-top: 15px;">
                    <label>
                        <input type="checkbox" id="pdm-om-force" name="pdm-om-force">
                        Forcer l'optimisation (Même si la taille ne diminue pas)
                    </label>
                </div>

                <div class="pdm-om-warning" id="pdm-om-quality-warning">
                    ⚠️ Un niveau élevé peut réduire la qualité visuelle.
                </div>
            </div>
            
            <div class="pdm-om-actions">
                <button type="button" class="button button-primary" id="pdm-om-scan-btn">Charger les médias</button>
                <button type="button" class="button button-secondary" id="pdm-om-optimize-btn" disabled>Optimiser la sélection</button>
            </div>
        </div>

        <!-- Progress Bar -->
        <div class="pdm-om-card pdm-om-progress-card" style="display: none;">
            <h2>Progression</h2>
            <div class="pdm-om-progress-container">
                <div class="pdm-om-progress-bar">
                    <div id="pdm-om-progress-fill" style="width: 0%;"></div>
                </div>
                <div class="pdm-om-progress-text">
                    <span id="pdm-om-progress-label">0%</span> - 
                    <span id="pdm-om-progress-count">0 / 0</span> images traitées
                </div>
            </div>
            <div id="pdm-om-status-msg"></div>
        </div>

        <!-- Stats -->
        <div class="pdm-om-card pdm-om-stats" style="display: none;">
            <h3>Résumé de l'optimisation</h3>
            <ul>
                <li>Images optimisées : <span id="pdm-om-stat-count">0</span></li>
                <li>Espace économisé : <span id="pdm-om-stat-savings">0 MB</span></li>
            </ul>
        </div>

        <!-- Media Table -->
        <div class="pdm-om-card pdm-om-table-container">
            <div class="pdm-om-filters">
                <input type="text" id="pdm-om-search" placeholder="Rechercher...">
                <select id="pdm-om-filter-type">
                    <option value="">Tous les types</option>
                    <option value="image/jpeg">JPEG</option>
                    <option value="image/png">PNG</option>
                    <option value="image/webp">WebP</option>
                </select>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td id="cb" class="manage-column column-cb check-column">
                            <input id="cb-select-all-1" type="checkbox">
                        </td>
                        <th scope="col" class="manage-column column-thumb">Aperçu</th>
                        <th scope="col" class="manage-column column-primary">Nom du fichier</th>
                        <th scope="col" class="manage-column column-size">Taille actuelle</th>
                        <th scope="col" class="manage-column column-status">Statut</th>
                        <th scope="col" class="manage-column column-actions">Actions</th>
                    </tr>
                </thead>
                <tbody id="pdm-om-media-list">
                    <tr>
                        <td colspan="6" style="text-align: center;">Veuillez charger les médias pour commencer.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Hidden File Input for Replacement -->
<input type="file" id="pdm-om-replace-input" style="display: none;" accept="image/jpeg,image/png,image/webp">
