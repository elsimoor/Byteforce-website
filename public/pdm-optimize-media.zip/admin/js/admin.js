jQuery(document).ready(function ($) {
    let allMedia = [];
    let selectedIds = [];
    let isProcessing = false;
    let totalSavings = 0;
    let processedCount = 0;

    // Range slider value update
    $('#pdm-om-level').on('input', function () {
        const val = $(this).val();
        $('#pdm-om-level-value').text(val);
        if (val >= 70) {
            $('#pdm-om-quality-warning').show();
        } else {
            $('#pdm-om-quality-warning').hide();
        }
    });

    // Show/Hide rename option
    $('#pdm-om-convert-webp').on('change', function () {
        if ($(this).is(':checked')) {
            $('#pdm-om-rename-wrap').slideDown();
        } else {
            $('#pdm-om-rename-wrap').slideUp();
            $('#pdm-om-rename-webp').prop('checked', false);
        }
    });

    // Scan Button
    $('#pdm-om-scan-btn').on('click', function () {
        $(this).prop('disabled', true).text(pdm_om_vars.strings.scanning);

        $.post(pdm_om_vars.ajax_url, {
            action: 'pdm_scan_media',
            nonce: pdm_om_vars.nonce
        }, function (response) {
            $('#pdm-om-scan-btn').prop('disabled', false).text('Charger les médias');
            if (response.success) {
                allMedia = response.data.images;
                renderMediaTable(allMedia);
            } else {
                alert(response.data);
            }
        });
    });

    function renderMediaTable(media) {
        const $tbody = $('#pdm-om-media-list');
        $tbody.empty();

        if (media.length === 0) {
            $tbody.append('<tr><td colspan="6" style="text-align: center;">Aucun média trouvé.</td></tr>');
            $('#pdm-om-optimize-btn').prop('disabled', true);
            return;
        }

        media.forEach(img => {
            const sizeFormatted = (img.size / 1024 / 1024).toFixed(2) + ' MB';
            const row = `
                <tr data-id="${img.id}">
                    <th scope="row" class="check-column">
                        <input type="checkbox" name="media_ids[]" value="${img.id}">
                    </th>
                    <td class="column-thumb"><img src="${img.thumbnail}" alt=""></td>
                    <td class="column-primary"><strong>${img.filename}</strong></td>
                    <td class="column-size">${sizeFormatted}</td>
                    <td class="column-status" id="status-${img.id}">Prêt</td>
                    <td class="column-actions">
                        <button type="button" class="button pdm-om-replace-btn" data-id="${img.id}">Remplacer</button>
                    </td>
                </tr>
            `;
            $tbody.append(row);
        });

        $('#pdm-om-optimize-btn').prop('disabled', false);
    }

    // Select All
    $('#cb-select-all-1').on('change', function () {
        $('input[name="media_ids[]"]').prop('checked', $(this).prop('checked'));
        updateSelectedCount();
    });

    $(document).on('change', 'input[name="media_ids[]"]', function () {
        updateSelectedCount();
    });

    function updateSelectedCount() {
        selectedIds = [];
        $('input[name="media_ids[]"]:checked').each(function () {
            selectedIds.push($(this).val());
        });
    }

    // Optimize Button
    $('#pdm-om-optimize-btn').on('click', function () {
        updateSelectedCount();
        if (selectedIds.length === 0) {
            alert('Veuillez sélectionner au moins une image.');
            return;
        }

        if (!confirm('Êtes-vous sûr de vouloir optimiser ' + selectedIds.length + ' images ? Les fichiers originaux seront écrasés.')) {
            return;
        }

        startOptimization();
    });

    function startOptimization() {
        isProcessing = true;
        processedCount = 0;
        totalSavings = 0;
        const total = selectedIds.length;
        const level = $('#pdm-om-level').val();
        const convertToWebp = $('#pdm-om-convert-webp').is(':checked') ? 1 : 0;
        const renameToWebp = $('#pdm-om-rename-webp').is(':checked') ? 1 : 0;
        const forceOptimize = $('#pdm-om-force').is(':checked') ? 1 : 0;

        $('#pdm-om-optimize-btn').prop('disabled', true);
        $('#pdm-om-scan-btn').prop('disabled', true);
        $('.pdm-om-progress-card').show();
        $('.pdm-om-stats').hide();

        updateProgress(0, total);
        processNextInQueue(level, total, convertToWebp, renameToWebp, forceOptimize);
    }

    function processNextInQueue(level, total, convertToWebp, renameToWebp, forceOptimize) {
        if (processedCount >= total) {
            finishOptimization();
            return;
        }

        const currentId = selectedIds[processedCount];
        const $status = $('#status-' + currentId);
        $status.text('Optimisation...');

        $.post(pdm_om_vars.ajax_url, {
            action: 'pdm_optimize_image',
            attachment_id: currentId,
            level: level,
            convert_webp: convertToWebp,
            rename_webp: renameToWebp,
            force_optimize: forceOptimize,
            nonce: pdm_om_vars.nonce
        }, function (response) {
            processedCount++;
            updateProgress(processedCount, total);

            if (response.success) {
                if (response.data.skipped) {
                    $status.html(`<span class="pdm-om-skipped" style="color: #646970;">Ignoré (Déjà optimisé)</span>`);
                } else {
                    const savings = response.data.savings;
                    totalSavings += savings;
                    const savingsMB = (savings / 1024 / 1024).toFixed(2);
                    $status.html(`<span class="pdm-om-success">Terminé (-${savingsMB} MB)</span>`);

                    // Update row size
                    const newSizeMB = (response.data.new_size / 1024 / 1024).toFixed(2);
                    $(`tr[data-id="${currentId}"] .column-size`).text(newSizeMB + ' MB');
                }

            } else {
                $status.html(`<span class="pdm-om-error">Erreur: ${response.data}</span>`);
            }

            processNextInQueue(level, total, convertToWebp, renameToWebp, forceOptimize);
        }).fail(function () {
            processedCount++;
            $status.html('<span class="pdm-om-error">Erreur serveur</span>');
            processNextInQueue(level, total, convertToWebp, renameToWebp, forceOptimize);
        });
    }

    function updateProgress(current, total) {
        const percent = Math.round((current / total) * 100);
        $('#pdm-om-progress-fill').css('width', percent + '%');
        $('#pdm-om-progress-label').text(percent + '%');
        $('#pdm-om-progress-count').text(current + ' / ' + total);
    }

    function finishOptimization() {
        isProcessing = false;
        $('#pdm-om-scan-btn').prop('disabled', false);
        $('#pdm-om-status-msg').text(pdm_om_vars.strings.finished);

        $('.pdm-om-stats').show();
        $('#pdm-om-stat-count').text(processedCount);
        $('#pdm-om-stat-savings').text((totalSavings / 1024 / 1024).toFixed(2) + ' MB');
    }

    // Filters logic (Local filtering)
    $('#pdm-om-search, #pdm-om-filter-type').on('input change', function () {
        const searchQuery = $('#pdm-om-search').val().toLowerCase();
        const typeFilter = $('#pdm-om-filter-type').val();

        const filtered = allMedia.filter(img => {
            const matchesSearch = img.filename.toLowerCase().includes(searchQuery);
            const matchesType = !typeFilter || img.mime_type === typeFilter;
            return matchesSearch && matchesType;
        });

        renderMediaTable(filtered);
    });

    // Replace Logic
    let currentReplaceId = null;
    $(document).on('click', '.pdm-om-replace-btn', function () {
        currentReplaceId = $(this).data('id');
        $('#pdm-om-replace-input').trigger('click');
    });

    $('#pdm-om-replace-input').on('change', function () {
        if (!this.files.length || !currentReplaceId) return;

        const file = this.files[0];
        const formData = new FormData();
        formData.append('action', 'pdm_replace_image');
        formData.append('attachment_id', currentReplaceId);
        formData.append('image_file', file);
        formData.append('nonce', pdm_om_vars.nonce);

        const $status = $('#status-' + currentReplaceId);
        $status.text('Remplacement...');

        $.ajax({
            url: pdm_om_vars.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response.success) {
                    const savings = response.data.savings;
                    totalSavings += savings;
                    updateGlobalSavingsUI(response.data.total_site_savings_formatted);

                    const savingsMB = (savings / 1024 / 1024).toFixed(2);
                    $status.html(`<span class="pdm-om-success">Remplacé (-${savingsMB} MB)</span>`);

                    // Update row size
                    const newSizeMB = (response.data.new_size / 1024 / 1024).toFixed(2);
                    $(`tr[data-id="${currentReplaceId}"] .column-size`).text(newSizeMB + ' MB');
                } else {
                    $status.html(`<span class="pdm-om-error">Erreur: ${response.data}</span>`);
                }
            },
            error: function () {
                $status.html('<span class="pdm-om-error">Erreur serveur</span>');
            }
        });

        // Reset input
        $(this).val('');
    });

    function updateGlobalSavingsUI(formatted) {
        $('#pdm-om-total-savings-site').text(formatted);
    }
});
