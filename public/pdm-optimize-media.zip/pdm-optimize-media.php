<?php
/**
 * Plugin Name:       PDM – Optimize Media
 * Description:       Optimise les images de la médiathèque WordPress sans modifier les URLs.
 * Version:           1.0.1
 * Author:            Walid moultamiss
 * Text Domain:       pdm-optimize-media
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PDM_OM_VERSION', '1.0.1' );
define( 'PDM_OM_PATH', plugin_dir_path( __FILE__ ) );
define( 'PDM_OM_URL', plugin_dir_url( __FILE__ ) );

// Registration logic
function pdm_om_activate() {
	// Check requirements
	if ( ! extension_loaded( 'gd' ) && ! extension_loaded( 'imagick' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die( 'This plugin requires either the GD or Imagick PHP extension to be installed and enabled.' );
	}
}
register_activation_hook( __FILE__, 'pdm_om_activate' );

// Load components
require_once PDM_OM_PATH . 'includes/class-pdm-optimizer.php';
require_once PDM_OM_PATH . 'includes/class-pdm-media-scanner.php';
require_once PDM_OM_PATH . 'includes/class-pdm-ajax-handler.php';
require_once PDM_OM_PATH . 'includes/class-pdm-admin.php';

// Initialize the plugin
function pdm_om_init() {
	new PDM_Admin();
	new PDM_AJAX_Handler();
}
add_action( 'plugins_loaded', 'pdm_om_init' );
