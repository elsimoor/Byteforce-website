<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PDM_Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function add_menu_page() {
		add_media_page(
			'PDM – Optimize Media',
			'Optimize Media',
			'manage_options',
			'pdm-optimize-media',
			array( $this, 'render_admin_page' )
		);
	}

	public function enqueue_assets( $hook ) {
		if ( 'media_page_pdm-optimize-media' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'pdm-om-admin-style', PDM_OM_URL . 'admin/css/admin.css', array(), PDM_OM_VERSION );
		wp_enqueue_script( 'pdm-om-admin-script', PDM_OM_URL . 'admin/js/admin.js', array( 'jquery' ), PDM_OM_VERSION, true );

		wp_localize_script( 'pdm-om-admin-script', 'pdm_om_vars', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'pdm_om_nonce' ),
			'strings'  => array(
				'scanning'    => 'Scanning media library...',
				'optimizing'  => 'Optimizing images...',
				'finished'    => 'Optimization complete!',
				'error'       => 'An error occurred.',
			)
		) );
	}

	public function render_admin_page() {
		include PDM_OM_PATH . 'admin/views/admin-page.php';
	}
}
