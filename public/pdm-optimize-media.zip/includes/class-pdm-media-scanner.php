<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PDM_Media_Scanner {

	/**
	 * Get images from the media library.
	 *
	 * @param array $args Filter arguments.
	 * @return array List of images.
	 */
	public function get_media( $args = array() ) {
		$defaults = array(
			'posts_per_page' => -1,
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/webp' ),
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		$query_args = wp_parse_args( $args, $defaults );
		$query = new WP_Query( $query_args );
		$images = array();

		foreach ( $query->posts as $post ) {
			$file_path = get_attached_file( $post->ID );
			if ( file_exists( $file_path ) ) {
				$images[] = array(
					'id'        => $post->ID,
					'filename'  => basename( $file_path ),
					'path'      => $file_path,
					'size'      => filesize( $file_path ),
					'url'       => wp_get_attachment_url( $post->ID ),
					'mime_type' => $post->post_mime_type,
					'date'      => $post->post_date,
					'thumbnail' => wp_get_attachment_thumb_url( $post->ID ),
				);
			}
		}

		return $images;
	}

	public function get_db_size() {
		global $wpdb;
		$res = $wpdb->get_results( $wpdb->prepare(
			"SELECT SUM(data_length + index_length) AS size FROM information_schema.TABLES WHERE table_schema = %s",
			DB_NAME
		) );
		return isset( $res[0]->size ) ? (int) $res[0]->size : 0;
	}
}
