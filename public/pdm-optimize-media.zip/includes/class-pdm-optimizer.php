<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PDM_Optimizer {

	/**
	 * Optimize an image given its attachment ID and optimization level.
	 *
	 * @param int $attachment_id The attachment ID.
	 * @param int $level Optimization level (10 to 90).
	 * @param bool $convert_webp Whether to convert to WebP.
	 * @param bool $rename_webp Whether to rename the file extension to .webp.
	 * @param bool $force_optimize Whether to force overwrite even if size increases.
	 * @return array|WP_Error Status and savings info or error.
	 */
	public function optimize( $attachment_id, $level, $convert_webp = false, $rename_webp = false, $force_optimize = false ) {
		$file_path = get_attached_file( $attachment_id );
		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error( 'file_not_found', 'File not found.' );
		}

		$mime_type = get_post_mime_type( $attachment_id );
		if ( $convert_webp || $rename_webp ) {
			$mime_type = 'image/webp';
		}

		$old_size = filesize( $file_path );
		$quality = 100 - $level;

		// Use a temporary file for optimization
		$temp_file = $file_path . '.tmp';
		$result = $this->compress_file( $file_path, $temp_file, $mime_type, $quality );

		if ( is_wp_error( $result ) ) {
			if ( file_exists( $temp_file ) ) unlink( $temp_file );
			return $result;
		}

		clearstatcache();
		$new_size = filesize( $temp_file );

		// If optimized file is larger or equal, and it's NOT a rename-to-webp request, cancel.
		// If it's a rename request, we might still want it if the user wants WebP format specifically,
		// but the user complained about size increase, so let's be strict.
		if ( $new_size >= $old_size && ! $force_optimize ) {
			unlink( $temp_file );
			return array(
				'old_size' => $old_size,
				'new_size' => $old_size,
				'savings'  => 0,
				'skipped'  => true,
				'message'  => 'Optimized file was larger or equal in size. Skipping.'
			);
		}

		// Overwrite original with temp
		if ( ! rename( $temp_file, $file_path ) ) {
			unlink( $temp_file );
			return new WP_Error( 'rename_error', 'Could not overwrite original file.' );
		}

		// Handle renaming extension if requested
		if ( $rename_webp && 'image/webp' === $mime_type ) {
			$path_info = pathinfo( $file_path );
			if ( strtolower( $path_info['extension'] ) !== 'webp' ) {
				$new_file_path = $path_info['dirname'] . '/' . $path_info['filename'] . '.webp';
				
				if ( rename( $file_path, $new_file_path ) ) {
					$file_path = $new_file_path;
					
					// Update WordPress metadata
					$relative_path = _wp_relative_upload_path( $file_path );
					update_post_meta( $attachment_id, '_wp_attached_file', $relative_path );
					
					// Update post mime type
					wp_update_post( array(
						'ID'             => $attachment_id,
						'post_mime_type' => 'image/webp',
						'guid'           => str_replace( '.' . $path_info['extension'], '.webp', get_the_guid( $attachment_id ) )
					) );
				}
			}
		}

		clearstatcache();
		$new_size = filesize( $file_path );

		// Regenerate metadata (thumbnails)
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$metadata = wp_generate_attachment_metadata( $attachment_id, $file_path );
		wp_update_attachment_metadata( $attachment_id, $metadata );

		return array(
			'old_size' => $old_size,
			'new_size' => $new_size,
			'savings'  => $old_size - $new_size,
		);
	}

	/**
	 * Compress a single file to a target path.
	 */
	private function compress_file( $source_path, $target_path, $mime_type, $quality ) {
		if ( extension_loaded( 'imagick' ) ) {
			return $this->compress_with_imagick( $source_path, $target_path, $mime_type, $quality );
		} elseif ( extension_loaded( 'gd' ) ) {
			return $this->compress_with_gd( $source_path, $target_path, $mime_type, $quality );
		}
		return new WP_Error( 'no_extension', 'No image processing extension available.' );
	}

	/**
	 * Compress using Imagick.
	 */
	private function compress_with_imagick( $source_path, $target_path, $mime_type, $quality ) {
		try {
			$image = new Imagick( $source_path );
			if ( 'image/jpeg' === $mime_type ) {
				$image->setImageCompression( Imagick::COMPRESSION_JPEG );
				$image->setImageCompressionQuality( $quality );
			} elseif ( 'image/png' === $mime_type ) {
				// PNG quality in Imagick is different (0-9 for compression level)
				// Level 9 is maximum compression.
				$png_quality = floor( $quality / 10 ); 
				$image->setCompressionQuality( $quality );
			} elseif ( 'image/webp' === $mime_type ) {
				$image->setImageFormat( 'webp' );
				$image->setImageCompression( Imagick::COMPRESSION_WEBP );
				$image->setImageCompressionQuality( $quality );
			}
			$image->stripImage(); // Remove metadata to save more space
			$image->writeImage( $target_path );
			$image->clear();
			$image->destroy();
			return true;
		} catch ( Exception $e ) {
			return new WP_Error( 'imagick_error', $e->getMessage() );
		}
	}

	/**
	 * Compress using GD.
	 */
	private function compress_with_gd( $source_path, $target_path, $target_mime, $quality ) {
		// Detect actual mime type of the file
		$info = getimagesize( $source_path );
		$source_mime = $info['mime'];

		if ( 'image/jpeg' === $source_mime ) {
			$image = imagecreatefromjpeg( $source_path );
		} elseif ( 'image/png' === $source_mime ) {
			$image = imagecreatefrompng( $source_path );
			if ( $image ) {
				imagealphablending( $image, false );
				imagesavealpha( $image, true );
			}
		} elseif ( 'image/webp' === $source_mime ) {
			$image = function_exists( 'imagecreatefromwebp' ) ? imagecreatefromwebp( $source_path ) : false;
		} else {
			return new WP_Error( 'gd_unsupported_source', 'Unsupported source format for GD.' );
		}

		if ( ! $image ) {
			return new WP_Error( 'gd_load_error', 'Failed to load image with GD.' );
		}

		// Save in target format
		if ( 'image/jpeg' === $target_mime ) {
			imagejpeg( $image, $target_path, $quality );
		} elseif ( 'image/png' === $target_mime ) {
			$gd_quality = 9 - floor( $quality / 10 );
			imagepng( $image, $target_path, $gd_quality );
		} elseif ( 'image/webp' === $target_mime ) {
			if ( ! function_exists( 'imagewebp' ) ) {
				imagedestroy( $image );
				return new WP_Error( 'gd_webp_not_supported', 'WebP output is not supported by your GD installation.' );
			}
			imagewebp( $image, $target_path, $quality );
		}

		imagedestroy( $image );
		return true;
	}

	/**
	 * Replace an attachment's file with a new upload.
	 */
	public function replace( $attachment_id, $file_array ) {
		$file_path = get_attached_file( $attachment_id );
		if ( ! $file_path || ! file_exists( $file_path ) ) {
			return new WP_Error( 'file_not_found', 'Original file not found.' );
		}

		$old_size = filesize( $file_path );
		
		// Move uploaded file to original path
		if ( ! move_uploaded_file( $file_array['tmp_name'], $file_path ) ) {
			return new WP_Error( 'upload_error', 'Could not move uploaded file.' );
		}

		clearstatcache();
		$new_size = filesize( $file_path );

		// Regenerate metadata (thumbnails)
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$metadata = wp_generate_attachment_metadata( $attachment_id, $file_path );
		wp_update_attachment_metadata( $attachment_id, $metadata );

		return array(
			'old_size' => $old_size,
			'new_size' => $new_size,
			'savings'  => $old_size - $new_size,
		);
	}
}
