<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PDM_AJAX_Handler {

	public function __construct() {
		add_action( 'wp_ajax_pdm_scan_media', array( $this, 'scan_media' ) );
		add_action( 'wp_ajax_pdm_optimize_image', array( $this, 'optimize_image' ) );
		add_action( 'wp_ajax_pdm_replace_image', array( $this, 'replace_image' ) );
	}

	public function scan_media() {
		check_ajax_referer( 'pdm_om_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Forbidden' );
		}

		$scanner = new PDM_Media_Scanner();
		$images = $scanner->get_media();

		wp_send_json_success( array(
			'images' => $images,
			'total'  => count( $images ),
		) );
	}

	public function optimize_image() {
		check_ajax_referer( 'pdm_om_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Forbidden' );
		}

		$attachment_id  = isset( $_POST['attachment_id'] ) ? intval( $_POST['attachment_id'] ) : 0;
		$level          = isset( $_POST['level'] ) ? intval( $_POST['level'] ) : 50;
		$convert_webp   = ! empty( $_POST['convert_webp'] );
		$rename_webp    = ! empty( $_POST['rename_webp'] );
		$force_optimize = ! empty( $_POST['force_optimize'] );

		if ( ! $attachment_id ) {
			wp_send_json_error( 'Invalid attachment ID' );
		}

		$optimizer = new PDM_Optimizer();
		$result = $optimizer->optimize( $attachment_id, $level, $convert_webp, $rename_webp, $force_optimize );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		// Update global savings
		if ( isset( $result['savings'] ) && $result['savings'] > 0 ) {
			$this->update_global_savings( $result['savings'] );
		}

		$result['total_site_savings_formatted'] = size_format( get_option( 'pdm_om_total_savings', 0 ) );

		wp_send_json_success( $result );
	}

	public function replace_image() {
		check_ajax_referer( 'pdm_om_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Forbidden' );
		}

		$attachment_id = isset( $_POST['attachment_id'] ) ? intval( $_POST['attachment_id'] ) : 0;
		if ( ! $attachment_id || empty( $_FILES['image_file'] ) ) {
			wp_send_json_error( 'Invalid data' );
		}

		$optimizer = new PDM_Optimizer();
		$result = $optimizer->replace( $attachment_id, $_FILES['image_file'] );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		// Update global savings
		if ( isset( $result['savings'] ) && $result['savings'] > 0 ) {
			$this->update_global_savings( $result['savings'] );
		}

		$result['total_site_savings_formatted'] = size_format( get_option( 'pdm_om_total_savings', 0 ) );

		wp_send_json_success( $result );
	}

	private function update_global_savings( $savings ) {
		$total = (int) get_option( 'pdm_om_total_savings', 0 );
		update_option( 'pdm_om_total_savings', $total + $savings );
	}
}
